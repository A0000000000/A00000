package com.a00000.service;

import com.a00000.bean.Friend;

public interface FriendService {

    boolean addNewFriend(Friend friend);

}

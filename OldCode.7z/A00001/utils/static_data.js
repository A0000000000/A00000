module.exports = {
    host: '127.0.0.1',
    port: 8080,
    before: '/A00000/',
    after: '.action',
    TOKEN: 'TOKEN',
    mongourl: 'mongodb://localhost/A00001'
}
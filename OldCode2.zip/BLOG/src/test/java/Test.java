import com.alibaba.fastjson.JSONObject;
import com.blog.App;
import com.blog.bean.dto.BaseActionResult;
import com.blog.bean.dto.BaseServiceResult;
import com.blog.bean.orm.table.SystemConfig;
import com.blog.bean.orm.view.UserView;
import com.blog.mapper.table.LogMapper;
import com.blog.mapper.table.SystemConfigMapper;
import com.blog.mapper.view.UserViewMapper;
import com.blog.service.mq.ProviderService;
import com.blog.service.mq.impl.ProviderServiceImpl;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit4.SpringRunner;

import java.sql.SQLException;
import java.util.*;

@SpringBootTest(classes = App.class)
@RunWith(SpringRunner.class)
public class Test {

    @Autowired
    private UserViewMapper mapper;

    @Autowired
    private LogMapper logMapper;
    @org.junit.Test
    public void test() throws SQLException {
        List<UserView> userViews = mapper.selectList(null);
        userViews.forEach(System.out::println);
    }

    @Autowired
    private SystemConfigMapper systemConfigMapper;
    @org.junit.Test
    public void test2() {
        System.out.println(systemConfigMapper);
    }

    @org.junit.Test
    public void test3() {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        String encode = encoder.encode("Aa.000000");
        System.out.println(encode);
    }

    @org.junit.Test
    public void test4() {
        String secret = "JXU0RUM1JXU0RUM1JXU2NjJGJXU0RTNBJXU0RTg2JXU1OTdEJXU3M0E5";
        Date expirationDate = new Date(System.currentTimeMillis() + 100000);
        Map<String, Object> claims = new HashMap<>();
        claims.put(Claims.SUBJECT, "A00000");
        claims.put(Claims.ISSUED_AT, new Date());
        String compact = Jwts.builder().setClaims(claims).setExpiration(expirationDate).signWith(SignatureAlgorithm.HS512, secret).compact();
        System.out.println(compact);
    }

    @Autowired
    private RedisTemplate<String, String> redisTemplate;
    @org.junit.Test
    public void test5() {
        ValueOperations<String, String> ops = redisTemplate.opsForValue();
        // ops.set("ABC", 123);
        redisTemplate.delete("ABC");
        System.out.println(ops.get("ABC"));
    }

    @Autowired
    private ProviderServiceImpl providerService;
    @org.junit.Test
    public void test6() {
        providerService.sendMessageToFile("123456");

    }

    @org.junit.Test
    public void test7() {
        BaseServiceResult<Void> res = new BaseServiceResult<>();
        BaseActionResult<Void> bean = res.getBaseActionResultBean();
        System.out.println(JSONObject.toJSONString(bean));
    }

}

package com.blog.mapper.view;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.view.BlogView;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 操作v_blog_view视图的Mapper接口
 */
@Mapper
@Repository
public interface BlogViewMapper extends BaseMapper<BlogView> {

    List<BlogView> selectByPage(@Param("form") PageForm<BlogView> form);

}

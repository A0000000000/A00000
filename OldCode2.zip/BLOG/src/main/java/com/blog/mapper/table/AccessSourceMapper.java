package com.blog.mapper.table;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.AccessSource;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 操作t_access_source表的接口
 */
@Mapper
@Repository
public interface AccessSourceMapper extends BaseMapper<AccessSource> {

    /**
     * 通过分页信息查询分页结果
     * @param form 分页信息
     * @return 分页结果
     */
    List<AccessSource> selectByPage(@Param("form") PageForm<AccessSource> form);

}

package com.blog.mapper.table;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.blog.bean.orm.table.Blog;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface BlogMapper extends BaseMapper<Blog> {

}

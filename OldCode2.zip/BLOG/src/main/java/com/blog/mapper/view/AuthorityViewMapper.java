package com.blog.mapper.view;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.blog.bean.orm.view.AuthorityView;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

/**
 * 操作v_authority_view视图的Mapper接口
 */
@Mapper
@Repository
public interface AuthorityViewMapper extends BaseMapper<AuthorityView> {

}

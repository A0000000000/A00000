package com.blog.mapper.view;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.view.UserView;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 操作v_user_view视图的Mapper接口
 */
@Mapper
@Repository
public interface UserViewMapper extends BaseMapper<UserView> {

    List<UserView> selectByPage(@Param("form") PageForm<UserView> form);

}

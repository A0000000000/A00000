package com.blog.mapper.table;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.Log;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 操作t_log表的Mapper接口
 */
@Mapper
@Repository
public interface LogMapper extends BaseMapper<Log> {

    List<Log> selectByPage(@Param("form") PageForm<Log> form);

}

package com.blog.mapper.table;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.blog.bean.orm.table.Creator;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface CreatorMapper extends BaseMapper<Creator> {
}

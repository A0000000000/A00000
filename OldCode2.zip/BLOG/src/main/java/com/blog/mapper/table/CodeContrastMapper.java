package com.blog.mapper.table;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.CodeContrast;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 操作t_code_contrast表的Mapper接口
 */
@Mapper
@Repository
public interface CodeContrastMapper extends BaseMapper<CodeContrast> {

    /**
     * 根据分页条件查询数据库
     * @param form 分页条件
     * @return 查询结果
     */
    List<CodeContrast> selectByPage(@Param("form") PageForm<CodeContrast> form);

}

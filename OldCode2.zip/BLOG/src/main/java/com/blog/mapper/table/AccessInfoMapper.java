package com.blog.mapper.table;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.AccessInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 操作t_access_info表的Mapper接口
 */
@Mapper
@Repository
public interface AccessInfoMapper extends BaseMapper<AccessInfo> {

    /**
     * 根据分页信息查询AccessInfo数据
     * @param form 分页信息
     * @return 查询结果
     */
    List<AccessInfo> selectByPage(@Param("form") PageForm<AccessInfo> form);

}

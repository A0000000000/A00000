package com.blog.mapper.table;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.Authority;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 操作t_authority表的Mapper接口
 */
@Mapper
@Repository
public interface AuthorityMapper extends BaseMapper<Authority> {

    List<Authority> selectByPage(@Param("form") PageForm<Authority> form);
}

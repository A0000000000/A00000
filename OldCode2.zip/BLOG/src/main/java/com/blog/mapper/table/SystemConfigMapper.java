package com.blog.mapper.table;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.SystemConfig;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 操作t_system_config表的Mapper接口
 */
@Mapper
@Repository
public interface SystemConfigMapper extends BaseMapper<SystemConfig> {

    List<SystemConfig> selectByPage(@Param("form") PageForm<SystemConfig> form);

}

package com.blog;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 网站的启动类, 启用组件扫描, 自动配置和Mapper扫描
 */
@SpringBootApplication
@MapperScan("com.blog.mapper.*")
public class App {

    public static void main(String[] args) {
        SpringApplication.run(App.class, args);
    }

}

package com.blog.bean.orm.view;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
@TableName("v_blog_view")
public class BlogView implements Serializable {

    @TableId(type = IdType.AUTO)
    private Integer id;
    private String title;
    private String content;
    @TableField("creator_id")
    private Integer creatorId;
    @TableField("create_time")
    private Date createTime;
    private String password;
    @TableField("visit_count")
    private Integer visitCount;
    private Integer star;
    @TableField("type_name")
    private String typeName;
    private String message;

}

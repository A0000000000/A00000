package com.blog.bean.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
public class BaseActionResult<T> implements Serializable {

    public static final Integer SUCCESS = 0;
    public static final Integer FAILED = 1;

    public BaseActionResult(T data) {
        this.data = data;
    }

    private Integer code = SUCCESS;
    private String message = null;
    private T data = null;

    public static BaseActionResult<Void> getSuccessBean() {
        return new BaseActionResult<>();
    }

    public static<T> BaseActionResult<T> getSuccessBean(T bean) {
        return new BaseActionResult<>(bean);
    }

    public static<T> BaseActionResult<T> getErrorBean(String message) {
        BaseActionResult<T> res = new BaseActionResult<>();
        res.setCode(BaseActionResult.FAILED);
        res.setMessage(message);
        return res;
    }

}

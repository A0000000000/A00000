package com.blog.bean.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BaseServiceResult<T> implements Serializable {

    private T data;
    private Exception e;

    public BaseServiceResult(T data) {
        this.data = data;
    }

    public BaseServiceResult(Exception e) {
        this.e = e;
    }

    public static<T> BaseServiceResult<T> getSuccessBean(T t) {
        return new BaseServiceResult<>(t);
    }

    public static BaseServiceResult<Void> getFailedBean(Exception e) {
        return new BaseServiceResult<>(e);
    }

    public static<T> BaseServiceResult<T> getBean(T data, Exception e) {
        return new BaseServiceResult<>(data, e);
    }

    public BaseActionResult<T> getBaseActionResultBean() {
        if (this.getE() != null && this.getData() == null) {
            return BaseActionResult.getErrorBean(this.getE().getMessage());
        }
        if (this.getE() == null && this.getData() != null) {
            return BaseActionResult.getSuccessBean(this.getData());
        }
        if (this.getE() == null && this.getData() == null) {
            return BaseActionResult.getSuccessBean(null);
        }
        BaseActionResult<T> res = new BaseActionResult<>();
        res.setData(this.getData());
        res.setMessage(this.getE().getMessage());
        res.setCode(null);
        return res;
    }

}

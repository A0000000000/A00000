package com.blog.bean.orm.table;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
@TableName("t_blog_tag")
public class BlogTag implements Serializable {

    @TableId(type = IdType.AUTO)
    private Integer id;
    @TableField("blog_id")
    private Integer blogId;
    @TableField("creator_id")
    private Integer creatorId;
    @TableField("tag_name")
    private String tagName;
    @TableField("add_time")
    private Date addTime;

}

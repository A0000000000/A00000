package com.blog.bean.orm.table;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
@TableName("t_blog_comment")
public class BlogComment implements Serializable {

    @TableId(type = IdType.AUTO)
    private Integer id;
    @TableField("blog_id")
    private Integer blogId;
    private String nickname;
    private String message;
    @TableField("comment_time")
    private Date commentTime;
    private Integer status;

}

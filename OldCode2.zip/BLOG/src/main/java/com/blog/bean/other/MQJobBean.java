package com.blog.bean.other;

import com.blog.bean.orm.table.Image;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.io.Serializable;
import java.util.Map;

@Data
public class MQJobBean implements Serializable {

    private String type;
    private String folder;
    private Map<String, MultipartFile> files;
    private Image image;

    private String target;
    private String title;
    private String content;


    public static MQJobBean getFileBean(String folder, Map<String, MultipartFile> files) {
        MQJobBean bean = new MQJobBean();
        bean.setFolder(folder);
        bean.setFiles(files);
        bean.setType("save");
        return bean;
    }

    public static MQJobBean getEmailBean(String target, String title, String content) {
        MQJobBean bean = new MQJobBean();
        bean.setTarget(target);
        bean.setTitle(title);
        bean.setContent(content);
        return bean;
    }

}

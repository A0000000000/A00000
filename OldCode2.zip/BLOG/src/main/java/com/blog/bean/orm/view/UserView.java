package com.blog.bean.orm.view;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;

@Data
@TableName("v_user_view")
@ToString
public class UserView implements Serializable {

    private Integer id;
    private String username;
    private String password;
    @TableField("create_time")
    private Date createTime;
    private String email;
    private String message;
    @TableField("file_directory")
    private String fileDirectory;
    private Integer status;
    private Date birthday;

}

package com.blog.bean.orm.table;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
@TableName("t_blog_info")
public class BlogInfo implements Serializable {

    @TableId(type = IdType.AUTO)
    private Integer id;
    @TableField("blog_id")
    private Integer blogId;
    @TableField("blog_type_id")
    private Integer blogTypeId;
    @TableField("creator_id")
    private Integer creatorId;
    @TableField("create_time")
    private Date createTime;
    private String password;
    @TableField("visit_count")
    private Integer visitCount;
    private Integer star;

}

package com.blog.bean.other;

import com.blog.bean.orm.view.UserView;
import lombok.Data;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;

@Data
public class JwtUser extends UserView implements UserDetails {

    private Collection<? extends GrantedAuthority> authorities;

    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }

    public boolean isAccountNonExpired() {
        return this.getStatus() == 0;
    }

    public boolean isAccountNonLocked() {
        return this.getStatus() == 0;
    }

    public boolean isCredentialsNonExpired() {
        return this.getStatus() == 0;
    }

    public boolean isEnabled() {
        return this.getStatus() == 0;
    }
}

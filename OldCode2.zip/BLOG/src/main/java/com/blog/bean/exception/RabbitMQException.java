package com.blog.bean.exception;

import lombok.Data;

@Data
public class RabbitMQException extends RuntimeException {

    public static final String TYPE_EMAIL = "email";
    public static final String TYPE_IMAGE = "image";

    public RabbitMQException(Exception e) {
        super(e);
    }

    private String type;
    private String additionMessage;

}

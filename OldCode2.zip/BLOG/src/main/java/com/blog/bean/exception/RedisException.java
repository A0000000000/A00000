package com.blog.bean.exception;

public class RedisException extends RuntimeException {

    public RedisException(Exception e) {
        super(e);
    }

    private String additionMessage;

    public String getAdditionMessage() {
        return additionMessage;
    }

    public void setAdditionMessage(String additionMessage) {
        this.additionMessage = additionMessage;
    }

}

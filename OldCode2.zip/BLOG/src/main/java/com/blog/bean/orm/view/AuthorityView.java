package com.blog.bean.orm.view;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;

@Data
@TableName("v_authority_view")
public class AuthorityView implements Serializable {

    @TableField("creator_id")
    private Integer creatorId;
    @TableField("authority_id")
    private Integer authorityId;
    @TableField("authority_name")
    private String authorityName;

}

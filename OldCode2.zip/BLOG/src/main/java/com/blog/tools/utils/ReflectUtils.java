package com.blog.tools.utils;

import java.lang.reflect.Field;

/**
 * 与反射相关的静态工具类
 */
public class ReflectUtils {

    /**
     * 通过字段名来获得某个对象的一个属性值
     * @param obj 要获取的对象
     * @param fieldName 字段名
     * @return 属性值
     */
    public static Object getValueByFieldName(Object obj, String fieldName) {
        try {
            Field field = null;
            for (Class<?> superClass = obj.getClass(); superClass != Object.class; superClass = superClass.getSuperclass()) {
                try {
                    field = superClass.getDeclaredField(fieldName);
                    break;
                } catch (NoSuchFieldException ignored) {
                }
            }
            Object value = null;
            if (field != null) {
                if (field.canAccess(obj)) {
                    value = field.get(obj);
                } else {
                    field.setAccessible(true);
                    value = field.get(obj);
                    field.setAccessible(false);
                }
            }
            return value;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 通过字段名来对某个对象设置属性
     * @param obj 被操纵对象
     * @param fieldName 属性名
     * @param value 属性值
     */
    public static void setValueByFieldName(Object obj, String fieldName, Object value) {
        try {
            Field field = obj.getClass().getDeclaredField(fieldName);
            if (field.canAccess(obj)) {
                field.set(obj, value);
            } else {
                field.setAccessible(true);
                field.set(obj, value);
                field.setAccessible(false);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}

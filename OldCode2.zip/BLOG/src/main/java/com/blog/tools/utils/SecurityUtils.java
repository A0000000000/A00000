package com.blog.tools.utils;

import com.blog.bean.other.JwtUser;
import org.springframework.security.core.context.SecurityContextHolder;

public class SecurityUtils {

    public static Integer getAuthenticationUserId() {
        Integer id = null;
        try {
            JwtUser jwtUser = (JwtUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            if (jwtUser != null) {
                id = jwtUser.getId();
            }
        } catch (Exception ignore) { }
        return id != null ? id : -1;
    }

    public static JwtUser getAuthenticationUser() {
        try {
            return (JwtUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        } catch (Exception ignore) { }
        return null;
    }

}

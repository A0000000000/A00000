package com.blog.tools.utils;

import com.blog.bean.orm.table.Image;
import com.blog.service.db.SystemConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.File;
import java.io.FileOutputStream;

@Component
public class FileUtils {

    @Autowired
    private SystemConfigService systemConfigService;

    private String fileRootPath;

    @PostConstruct
    public void init() {
        fileRootPath = systemConfigService.selectUseName("file_root_path").getValue();
    }

    public void saveFileToDisk(String filename, String folder, byte[] file) throws Exception {
        String fullFolder = String.format("%s\\%s", fileRootPath, folder);
        File folderFile = new File(fullFolder);
        if (!folderFile.exists()) {
            folderFile.mkdirs();
        }
        File image = new File(folderFile, filename);
        if (image.exists()) {
            image.delete();
        }
        try (FileOutputStream fos = new FileOutputStream(image)) {
            fos.write(file);
            fos.flush();
        }
    }

    public void deleteFileFromDisk(String folder, Image image) {
        String filePath = String.format("%s\\%s\\%s", fileRootPath, folder, image.getFilename());
        File file = new File(filePath);
        if (file.exists()) {
            file.delete();
        }
    }
}

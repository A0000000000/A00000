package com.blog.tools.constant;

public class StaticConstant {

    public static final String EMPTY_ARGS = "EmptyArgs";
    public static final String SERVER_ERROR = "ServerError";
    public static final String PARAMETER_ERROR = "ParameterError";
    public static final String REPEAT_USERNAME = "RepeatUsername";
    public static final String PERMISSION_DENIED = "PermissionDenied";
    public static final String LOGIN_INFO_ERROR = "LoginInfoError";
    public static final String AUTHENTIC_FAILED = "AuthenticFailed";
    public static final String NOT_FOUND = "NotFound";
    public static final String UNKNOWN_SOURCE = "UnknownSource";
    public static final String EMPTY_SOURCE = "EmptySource";

}

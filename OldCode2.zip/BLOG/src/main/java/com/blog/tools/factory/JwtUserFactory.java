package com.blog.tools.factory;

import com.blog.bean.orm.view.AuthorityView;
import com.blog.bean.orm.view.UserView;
import com.blog.bean.other.JwtUser;
import org.springframework.beans.BeanUtils;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.Collection;
import java.util.stream.Collectors;

/**
 * 提供和JwtUser相关的静态方法
 */
public class JwtUserFactory {

    /**
     * 通过用户信息和权限信息创建一个JwtUser对像
     * @param userView 用户信息
     * @param authorities 权限信息
     * @return 封装好的对象
     */
    public static JwtUser createJwtUser(UserView userView, Collection<AuthorityView> authorities) {
        JwtUser user = new JwtUser();
        BeanUtils.copyProperties(userView, user);
        user.setAuthorities(authorities.stream().map(item -> new SimpleGrantedAuthority(item.getAuthorityName())).collect(Collectors.toList()));
        return user;
    }

}

package com.blog.tools.utils;

import com.blog.service.db.SystemConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
public class EmailUtils {

    @Autowired
    private SystemConfigService systemConfigService;

    private String username;
    private String password;
    private String host;

    @PostConstruct
    public void init() {
        username = systemConfigService.selectUseName("username").getValue();
        password = systemConfigService.selectUseName("password").getValue();
        host = systemConfigService.selectUseName("host").getValue();
    }

    public void sendEmail(String target, String title, String content) throws Exception {

    }

}

package com.blog.controller;

import com.blog.bean.dto.BaseActionResult;
import com.blog.bean.dto.BaseServiceResult;
import com.blog.bean.dto.PageBean;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.*;
import com.blog.bean.orm.view.BlogView;
import com.blog.service.surface.GuestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 访客相关操作的控制器
 */
@RestController
@RequestMapping("/api/guest")
public class GuestController {

    @Autowired
    private GuestService guestService;

    @PostMapping("/blogTitleGet")
    public BaseActionResult<PageBean<BlogView>> blogTitleGet(@RequestBody PageForm<BlogView> form) {
        BaseServiceResult<PageBean<BlogView>> result = guestService.getBlogView(form);
        return result.getBaseActionResultBean();
    }

    @PostMapping("/blogViewGet")
    public BaseActionResult<BlogView> blogViewGet(@RequestBody BlogView blogView) {
        BaseServiceResult<BlogView> result = guestService.getBlogView(blogView);
        return result.getBaseActionResultBean();
    }

    @PostMapping("/imageGet")
    public BaseActionResult<PageBean<Image>> imageGet(@RequestBody PageForm<Image> form) {
        BaseServiceResult<PageBean<Image>> result = guestService.getImage(form);
        return result.getBaseActionResultBean();
    }

    @PostMapping("/blogCommentAdd")
    public BaseActionResult<BlogComment> blogCommentAdd(@RequestBody BlogComment blogComment) {
        BaseServiceResult<BlogComment> result = guestService.postBlogComment(blogComment);
        return result.getBaseActionResultBean();
    }

    @PostMapping("/friendAdd")
    public BaseActionResult<Friend> friendAdd(@RequestBody Friend friend) {
        BaseServiceResult<Friend> result = guestService.postFriend(friend);
        return result.getBaseActionResultBean();
    }

    @PostMapping("/blogTagGet")
    public BaseActionResult<List<BlogTag>> blogTagGet(@RequestBody BlogView blogView) {
        BaseServiceResult<List<BlogTag>> result = guestService.getBlogTag(blogView);
        return result.getBaseActionResultBean();
    }

}

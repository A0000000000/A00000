package com.blog.controller;

import com.blog.bean.dto.BaseActionResult;
import com.blog.bean.orm.table.Creator;
import com.blog.bean.orm.table.Image;
import com.blog.bean.orm.table.SystemConfig;
import com.blog.bean.orm.view.UserView;
import com.blog.bean.other.JwtUser;
import com.blog.service.db.*;
import com.blog.service.surface.impl.JwtUserDetailsServiceImpl;
import com.blog.tools.constant.StaticConstant;
import com.blog.tools.utils.JwtTokenUtils;
import com.blog.tools.utils.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.PostConstruct;
import java.io.FileInputStream;
import java.util.Collection;
import java.util.concurrent.atomic.AtomicReference;

@RestController
@RequestMapping("/api/other")
public class OtherController {

    @Autowired
    private ImageService imageService;
    @Autowired
    private SystemConfigService systemConfigService;
    @Autowired
    private UserViewService userViewService;
    @Autowired
    private CodeContrastService codeContrastService;
    @Autowired
    private JwtUserDetailsServiceImpl jwtUserDetailsService;
    @Autowired
    private JwtTokenUtils jwtTokenUtils;
    @Autowired
    private CreatorService creatorService;


    private String fileRootPath;

    @PostConstruct
    public void init() {
        fileRootPath = systemConfigService.selectUseName("file_root_path").getValue();
    }

    @RequestMapping("/imageStreamGet")
    public byte[] imageStreamGet(Image image) {
        Image currentImage = imageService.selectUseId(image.getId());
        if (StringUtils.isEmpty(currentImage.getPassword()) || currentImage.getPassword().equals(image.getPassword())) {
            UserView userView = userViewService.selectUseId(currentImage.getCreatorId());
            String fullFilePath = String.format("%s\\%s\\%s", fileRootPath, userView.getFileDirectory(), currentImage.getFilename());
            try (FileInputStream fis = new FileInputStream(fullFilePath)) {
                return fis.readAllBytes();
            } catch (Exception e) {
                return null;
            }
        } else {
            return null;
        }
    }

    @RequestMapping("/visitCountAdd")
    public BaseActionResult<Long> visitCountAdd() {
        try {
            SystemConfig config = systemConfigService.selectUseName("visit_count");
            if (config != null) {
                config.setValue(String.valueOf(Long.parseLong(config.getValue()) + 1));
                Integer num = systemConfigService.update(config);
                if (num < 1) {
                    throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
                }
                return new BaseActionResult<>(Long.parseLong(config.getValue()));
            } else {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
        } catch (Exception e) {
            return BaseActionResult.getErrorBean(e.getMessage());
        }
    }

    @RequestMapping("/visitCountGet")
    public BaseActionResult<Long> visitCountGet() {
        try {
            SystemConfig config = systemConfigService.selectUseName("visit_count");
            if (config == null) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
            return new BaseActionResult<>(Long.parseLong(config.getValue()));
        } catch (Exception e) {
            return BaseActionResult.getErrorBean(e.getMessage());
        }
    }


    @RequestMapping("/websiteCreateTimeGet")
    public BaseActionResult<String> websiteCreateTimeGet() {
        try {
            SystemConfig config = systemConfigService.selectUseName("create_time");
            if (config == null) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
            return new BaseActionResult<>(config.getValue());
        } catch (Exception e) {
            return BaseActionResult.getErrorBean(e.getMessage());
        }
    }

    @RequestMapping("/isAdmin")
    public BaseActionResult<Boolean> isAdmin() {
        try {
            Integer id = SecurityUtils.getAuthenticationUserId();
            UserView userView = userViewService.selectUseId(id);
            JwtUser user = (JwtUser) jwtUserDetailsService.loadUserByUsername(userView.getUsername());
            Collection<? extends GrantedAuthority> authorities = user.getAuthorities();
            AtomicReference<Boolean> res = new AtomicReference<>(false);
            authorities.forEach(item -> {
                if ("ROLE_ADMIN".equals(item.getAuthority())) {
                    res.set(true);
                }
            });
            return BaseActionResult.getSuccessBean(res.get());
        } catch (Exception e) {
            return BaseActionResult.getErrorBean(e.getMessage());
        }
    }

    @PostMapping("/flushToken")
    public BaseActionResult<String> flushToken(@RequestBody String token) {
        try {
            String newToken = jwtTokenUtils.refreshToken(token);
            return BaseActionResult.getSuccessBean(newToken);
        } catch (Exception e) {
            return BaseActionResult.getErrorBean(e.getMessage());
        }
    }

    @PostMapping("/getUsername")
    public BaseActionResult<String> getUsername(@RequestBody Creator creator) {
        try {
            Creator target = creatorService.selectUseId(creator.getId());
            return BaseActionResult.getSuccessBean(target.getUsername());
        } catch (Exception e) {
            return BaseActionResult.getErrorBean(e.getMessage());
        }
    }

}

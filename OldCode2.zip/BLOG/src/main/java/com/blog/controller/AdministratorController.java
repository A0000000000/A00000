package com.blog.controller;

import com.blog.bean.dto.BaseActionResult;
import com.blog.bean.dto.BaseServiceResult;
import com.blog.bean.dto.PageBean;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.*;
import com.blog.bean.orm.view.UserView;
import com.blog.service.surface.AdministratorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 管理员相关操作的控制器
 */
@RestController
@RequestMapping("/api/admin")
public class AdministratorController {

    @Autowired
    private AdministratorService administratorService;

    // 日志相关操作
    @PostMapping("/systemLogGet")
    public BaseActionResult<PageBean<Log>> systemLogGet(@RequestBody PageForm<Log> form) {
        BaseServiceResult<PageBean<Log>> result = administratorService.getSystemLog(form);
        return result.getBaseActionResultBean();
    }

    // 访问信息相关操作
    @PostMapping("/accessInfoGet")
    public BaseActionResult<PageBean<AccessInfo>> accessInfoGet(@RequestBody PageForm<AccessInfo> form) {
        BaseServiceResult<PageBean<AccessInfo>> result = administratorService.getAccessInfo(form);
        return result.getBaseActionResultBean();
    }

    // 错误对照码表相关操作
    @PostMapping("/codeContrastGet")
    public BaseActionResult<PageBean<CodeContrast>> codeContrastGet(@RequestBody PageForm<CodeContrast> form) {
        BaseServiceResult<PageBean<CodeContrast>> result = administratorService.getCodeContrast(form);
        return result.getBaseActionResultBean();
    }

    @PostMapping("/codeContrastAdd")
    public BaseActionResult<CodeContrast> codeContrastAdd(@RequestBody CodeContrast codeContrast) {
        BaseServiceResult<CodeContrast> result = administratorService.postCodeContrast(codeContrast);
        return result.getBaseActionResultBean();
    }

    @PostMapping("/codeContrastRemove")
    public BaseActionResult<Void> codeContrastRemove(@RequestBody CodeContrast codeContrast) {
        BaseServiceResult<Void> result = administratorService.deleteCodeContrast(codeContrast);
        return result.getBaseActionResultBean();
    }

    // 访问来源相关接口
    @PostMapping("/accessSourceGet")
    public BaseActionResult<PageBean<AccessSource>> accessSourceGet(@RequestBody PageForm<AccessSource> form) {
        BaseServiceResult<PageBean<AccessSource>> result = administratorService.getAccessSource(form);
        return result.getBaseActionResultBean();
    }

    @PostMapping("/accessSourceAdd")
    public BaseActionResult<AccessSource> accessSourceAdd(@RequestBody AccessSource accessSource) {
        BaseServiceResult<AccessSource> result = administratorService.postAccessSource(accessSource);
        return result.getBaseActionResultBean();
    }

    @PostMapping("/accessSourceRemove")
    public BaseActionResult<Void> accessSourceRemove(@RequestBody AccessSource accessSource) {
        BaseServiceResult<Void> result = administratorService.deleteAccessSource(accessSource);
        return result.getBaseActionResultBean();
    }

    // 系统信息配置相关接口
    @PostMapping("/systemConfigGet")
    public BaseActionResult<PageBean<SystemConfig>> systemConfigGet(@RequestBody PageForm<SystemConfig> form) {
        BaseServiceResult<PageBean<SystemConfig>> result = administratorService.getSystemConfig(form);
        return result.getBaseActionResultBean();
    }

    @PostMapping("/systemConfigAdd")
    public BaseActionResult<SystemConfig> systemConfigAdd(@RequestBody SystemConfig systemConfig) {
        BaseServiceResult<SystemConfig> result = administratorService.postSystemConfig(systemConfig);
        return result.getBaseActionResultBean();
    }

    @PostMapping("/systemConfigUpdate")
    public BaseActionResult<SystemConfig> systemConfigUpdate(@RequestBody SystemConfig systemConfig) {
        BaseServiceResult<SystemConfig> result = administratorService.putSystemConfig(systemConfig);
        return result.getBaseActionResultBean();
    }

    @PostMapping("/systemConfigRemove")
    public BaseActionResult<Void> systemConfigRemove(@RequestBody SystemConfig systemConfig) {
        BaseServiceResult<Void> result = administratorService.deleteSystemConfig(systemConfig);
        return result.getBaseActionResultBean();
    }

    // 权限表配置相关接口
    @PostMapping("/authorityGet")
    public BaseActionResult<PageBean<Authority>> authorityGet(@RequestBody PageForm<Authority> form) {
        BaseServiceResult<PageBean<Authority>> result = administratorService.getAuthority(form);
        return result.getBaseActionResultBean();
    }

    // 用户视图相关接口
    @PostMapping("/userViewGet")
    public BaseActionResult<PageBean<UserView>> userViewGet(@RequestBody PageForm<UserView> form) {
        BaseServiceResult<PageBean<UserView>> result = administratorService.getUserView(form);
        return result.getBaseActionResultBean();
    }

    @PostMapping("/userViewAdd")
    public BaseActionResult<UserView> userViewAdd(@RequestBody UserView userView) {
        BaseServiceResult<UserView> result = administratorService.postUserView(userView);
        return result.getBaseActionResultBean();
    }

    @PostMapping("/userViewUpdate")
    public BaseActionResult<UserView> userViewUpdate(@RequestBody UserView userView) {
        BaseServiceResult<UserView> result = administratorService.putUserView(userView);
        return result.getBaseActionResultBean();
    }

    // 用户身份相关接口
    @PostMapping("/creatorAuthorityAdd")
    public BaseActionResult<CreatorAuthority> creatorAuthorityAdd(@RequestBody CreatorAuthority creatorAuthority) {
        BaseServiceResult<CreatorAuthority> result = administratorService.postCreatorAuthority(creatorAuthority);
        return result.getBaseActionResultBean();
    }

    @PostMapping("/creatorAuthorityRemove")
    public BaseActionResult<Void> creatorAuthorityRemove(@RequestBody CreatorAuthority creatorAuthority) {
        BaseServiceResult<Void> result = administratorService.deleteCreatorAuthority(creatorAuthority);
        return result.getBaseActionResultBean();
    }

}

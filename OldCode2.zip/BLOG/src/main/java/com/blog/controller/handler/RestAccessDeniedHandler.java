package com.blog.controller.handler;

import com.alibaba.fastjson.JSONObject;
import com.blog.bean.dto.BaseActionResult;
import com.blog.service.db.CodeContrastService;
import com.blog.tools.constant.StaticConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * 权限不足时的Handler
 */
@Component
public class RestAccessDeniedHandler implements AccessDeniedHandler {

    @Autowired
    private CodeContrastService codeContrastService;

    @Override
    public void handle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, AccessDeniedException e) throws IOException, ServletException {
        BaseActionResult<Void> action = BaseActionResult.getErrorBean(codeContrastService.selectUseName(StaticConstant.PERMISSION_DENIED).getValue());
        String str = JSONObject.toJSONString(action);
        httpServletResponse.setContentType("application/json;charset=UTF-8");
        try (ServletOutputStream outputStream = httpServletResponse.getOutputStream()) {
            outputStream.write(str.getBytes(StandardCharsets.UTF_8));
            outputStream.flush();
        }
    }
}

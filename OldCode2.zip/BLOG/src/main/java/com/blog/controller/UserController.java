package com.blog.controller;

import com.blog.bean.dto.BaseActionResult;
import com.blog.bean.dto.BaseServiceResult;
import com.blog.bean.dto.PageBean;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.*;
import com.blog.bean.orm.view.BlogView;
import com.blog.bean.orm.view.UserView;
import com.blog.service.surface.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 用户相关操作的控制器
 */
@RestController
@RequestMapping("/api/user")
public class UserController {

    @Autowired
    private UserService userService;

    // 用户视图相关操作
    @PostMapping("/userViewGet")
    public BaseActionResult<UserView> userViewGet() {
        BaseServiceResult<UserView> result = userService.getUserView();
        return result.getBaseActionResultBean();
    }

    @PostMapping("/userViewUpdate")
    public BaseActionResult<UserView> userViewUpdate(@RequestBody UserView userView) {
        BaseServiceResult<UserView> result = userService.putUserView(userView);
        return result.getBaseActionResultBean();
    }

    @PostMapping("/userViewRemove")
    public BaseActionResult<Void> userViewRemove() {
        BaseServiceResult<Void> result = userService.deleteUserView();
        return result.getBaseActionResultBean();
    }

    // 博客相关操作
    @PostMapping("/blogAdd")
    public BaseActionResult<BlogView> blogAdd(@RequestBody BlogView blogView) {
        BaseServiceResult<BlogView> result = userService.postBlogView(blogView);
        return result.getBaseActionResultBean();
    }

    @PostMapping("/blogUpdate")
    public BaseActionResult<BlogView> blogUpdate(@RequestBody BlogView blogView) {
        BaseServiceResult<BlogView> result = userService.putBlogView(blogView);
        return result.getBaseActionResultBean();
    }

    // 博客类型相关操作
    @PostMapping("/blogTypeAdd")
    public BaseActionResult<BlogType> blogTypeAdd(@RequestBody BlogType blogType) {
        BaseServiceResult<BlogType> result = userService.postBlogType(blogType);
        return result.getBaseActionResultBean();
    }

    @PostMapping("/blogTypeRemove")
    public BaseActionResult<Void> blogTypeRemove(@RequestBody BlogType blogType) {
        BaseServiceResult<Void> result = userService.deleteBlogType(blogType);
        return result.getBaseActionResultBean();
    }

    @PostMapping("/blogTypeGet")
    public BaseActionResult<PageBean<BlogType>> blogTypeGet(@RequestBody PageForm<BlogType> form) {
        BaseServiceResult<PageBean<BlogType>> result = userService.getBlogType(form);
        return result.getBaseActionResultBean();
    }

    // 博客标签相关操作
    @PostMapping("/blogTagAdd")
    public BaseActionResult<BlogTag> blogTagAdd(@RequestBody BlogTag blogTag) {
        BaseServiceResult<BlogTag> result = userService.postBlogTag(blogTag);
        return result.getBaseActionResultBean();
    }

    @PostMapping("/blogTagRemove")
    public BaseActionResult<Void> blogTagRemove(@RequestBody BlogTag blogTag) {
        BaseServiceResult<Void> result = userService.deleteBlogTag(blogTag);
        return result.getBaseActionResultBean();
    }

    @PostMapping("/imageAdd")
    public BaseActionResult<List<Image>> imageAdd(@RequestParam("images")MultipartFile[] images, @RequestParam("blogId") Integer blogId) {
        BaseServiceResult<List<Image>> result = userService.postImage(images, blogId);
        return result.getBaseActionResultBean();
    }

    @PostMapping("/imageRemove")
    public BaseActionResult<Void> imageRemove(@RequestBody Image image) {
        BaseServiceResult<Void> result = userService.deleteImage(image);
        return result.getBaseActionResultBean();
    }

    @PostMapping("/friendGet")
    public BaseActionResult<PageBean<Friend>> friendGet(@RequestBody PageForm<Friend> form) {
        BaseServiceResult<PageBean<Friend>> result = userService.getFriend(form);
        return result.getBaseActionResultBean();
    }

}

package com.blog.controller.handler;

import com.blog.bean.dto.BaseActionResult;
import com.blog.service.db.CodeContrastService;
import com.blog.tools.constant.StaticConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.NoHandlerFoundException;

import javax.servlet.http.HttpServletRequest;

/**
 * 访问一个不存在的URL时的Handler
 */
@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    @Autowired
    private CodeContrastService codeContrastService;

    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public BaseActionResult<Void> defaultErrorHandler(HttpServletRequest request, Exception e) {
        if (e instanceof NoHandlerFoundException) {
            return BaseActionResult.getErrorBean(codeContrastService.selectUseName(StaticConstant.NOT_FOUND).getValue());
        } else {
            return BaseActionResult.getErrorBean(e.getMessage());
        }
    }

}

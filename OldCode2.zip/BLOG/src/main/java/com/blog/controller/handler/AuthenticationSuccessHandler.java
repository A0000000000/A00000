package com.blog.controller.handler;

import com.alibaba.fastjson.JSONObject;
import com.blog.bean.dto.BaseActionResult;
import com.blog.tools.utils.JwtTokenUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * 登录成功时的Handler
 */
@Component
public class AuthenticationSuccessHandler implements org.springframework.security.web.authentication.AuthenticationSuccessHandler {

    @Autowired
    private JwtTokenUtils jwtTokenUtil;

    @Override
    public void onAuthenticationSuccess(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Authentication authentication) throws IOException, ServletException {
        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        SecurityContextHolder.getContext().setAuthentication(authentication);
        String token = jwtTokenUtil.generateToken(userDetails);
        httpServletResponse.setContentType("application/json;charset=UTF-8");
        try (ServletOutputStream outputStream = httpServletResponse.getOutputStream()) {
            Map<String, Object> m = new HashMap<>();
            m.put("token", token);
            BaseActionResult<Map<String, Object>> resultAction = BaseActionResult.getSuccessBean(m);
            String str = JSONObject.toJSONString(resultAction);
            outputStream.write(str.getBytes(StandardCharsets.UTF_8));
            outputStream.flush();
        }
    }
}

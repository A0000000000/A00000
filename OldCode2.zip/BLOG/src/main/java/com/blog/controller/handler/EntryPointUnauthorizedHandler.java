package com.blog.controller.handler;

import com.alibaba.fastjson.JSONObject;
import com.blog.bean.dto.BaseActionResult;
import com.blog.service.db.CodeContrastService;
import com.blog.tools.constant.StaticConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * 认证失败是的Handler
 */
@Component
public class EntryPointUnauthorizedHandler implements AuthenticationEntryPoint {

    @Autowired
    private CodeContrastService codeContrastService;

    @Override
    public void commence(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, AuthenticationException e) throws IOException {
        BaseActionResult<Void> action = BaseActionResult.getErrorBean(codeContrastService.selectUseName(StaticConstant.AUTHENTIC_FAILED).getValue());
        String str = JSONObject.toJSONString(action);
        httpServletResponse.setContentType("application/json;charset=UTF-8");
        try (ServletOutputStream outputStream = httpServletResponse.getOutputStream()) {
            outputStream.write(str.getBytes(StandardCharsets.UTF_8));
            outputStream.flush();
        }
    }
}

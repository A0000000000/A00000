package com.blog.config.interceptor;

import com.blog.aop.interceptor.AccessInfoInterceptor;
import com.blog.aop.interceptor.AccessSourceInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

/**
 * 配置Spring MVC的拦截器
 */
@Configuration
public class InterceptorAppConfig extends WebMvcConfigurationSupport {

    @Autowired
    private AccessInfoInterceptor accessInfoInterceptor;
    @Autowired
    private AccessSourceInterceptor accessSourceInterceptor;

    // 配置需要拦截URL的规则
    @Override
    protected void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/**");
        super.addResourceHandlers(registry);
    }

    // 配置具体的拦截器
    @Override
    protected void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(accessInfoInterceptor).addPathPatterns("/**");
        registry.addInterceptor(accessSourceInterceptor).addPathPatterns("/**");
        super.addInterceptors(registry);
    }

}

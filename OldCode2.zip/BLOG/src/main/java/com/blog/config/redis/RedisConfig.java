package com.blog.config.redis;

import com.blog.bean.other.MQJobBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;

@Configuration
public class RedisConfig {

    @Bean
    public RedisTemplate<String, MQJobBean> getRedisTemplate(RedisConnectionFactory redisConnectionFactory) {
        RedisTemplate<String, MQJobBean> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(redisConnectionFactory);
        return redisTemplate;
    }

}

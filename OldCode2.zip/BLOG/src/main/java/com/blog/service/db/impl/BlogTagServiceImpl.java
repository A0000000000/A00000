package com.blog.service.db.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.blog.bean.orm.table.BlogTag;
import com.blog.mapper.table.BlogTagMapper;
import com.blog.service.db.BlogTagService;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component
@Transactional
public class BlogTagServiceImpl extends BaseDBServiceImpl<BlogTag, BlogTagMapper> implements BlogTagService {

    @Override
    public List<BlogTag> selectUseBlogId(Integer id) {
        QueryWrapper<BlogTag> qw = new QueryWrapper<>();
        qw.eq("blog_id", id);
        return u.selectList(qw);
    }

}

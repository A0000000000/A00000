package com.blog.service.mq.impl;

import com.blog.service.mq.ProviderService;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 将具体消息发送到消息队列的业务层实现类
 */
@Component
public class ProviderServiceImpl implements ProviderService {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    /**
     * 消息具体发送者
     * @param exchange 要发送的目标主机
     * @param routingKey 要发送的路由Key
     * @param message 要发送的消息
     */
    private void sendMessageToMQ(String exchange, String routingKey, String message) {
        rabbitTemplate.convertAndSend(exchange, routingKey, message);
    }

    /**
     * 发送一条保存文件的消息
     * @param message 消息
     */
    @Override
    public void sendMessageToFile(String message) {
        String exchange = "file";
        String routingKey = "image";
        sendMessageToMQ(exchange, routingKey, message);
    }

    /**
     * 发送一条邮件相关的消息
     * @param message 消息
     */
    @Override
    public void sendMessageToEmail(String message) {
        String exchange = "email";
        String routingKey = "email";
        sendMessageToMQ(exchange, routingKey, message);
    }

}

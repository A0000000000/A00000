package com.blog.service.db;

import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.Log;
import com.blog.mapper.table.LogMapper;

import java.util.List;

/**
 * 操作Log表相关的业务层接口
 */
public interface LogService extends BaseDBService<Log, LogMapper> {

    /**
     * 通过分页条件, 查询日志数据
     * @param form 分页条件
     * @return 日志列表
     */
    List<Log> selectUseForm(PageForm<Log> form);

}

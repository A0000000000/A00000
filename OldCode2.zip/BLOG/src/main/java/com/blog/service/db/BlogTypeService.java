package com.blog.service.db;

import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.BlogType;
import com.blog.mapper.table.BlogTypeMapper;

import java.util.List;

public interface BlogTypeService extends BaseDBService<BlogType, BlogTypeMapper>{

    BlogType selectUseTypeName(String typeName);

    List<BlogType> selectUseForm(PageForm<BlogType> form);

}

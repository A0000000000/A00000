package com.blog.service.redis;

import com.blog.bean.other.MQJobBean;

public interface JobDataService {

    String addJobToRedis(MQJobBean bean);

    MQJobBean getJobFromRedis(String key);

    Boolean removeJobFromRedis(String key);

    Boolean hasJobInRedis(String key);

}

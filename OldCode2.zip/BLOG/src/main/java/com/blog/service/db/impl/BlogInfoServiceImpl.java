package com.blog.service.db.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.blog.bean.orm.table.BlogInfo;
import com.blog.mapper.table.BlogInfoMapper;
import com.blog.service.db.BlogInfoService;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class BlogInfoServiceImpl extends BaseDBServiceImpl<BlogInfo, BlogInfoMapper> implements BlogInfoService {

    @Override
    public BlogInfo selectUseBlogId(Integer id) {
        QueryWrapper<BlogInfo> qw = new QueryWrapper<>();
        qw.eq("blog_id", id);
        return u.selectOne(qw);
    }
}

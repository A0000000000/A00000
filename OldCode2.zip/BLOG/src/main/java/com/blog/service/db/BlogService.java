package com.blog.service.db;

import com.blog.bean.orm.table.Blog;
import com.blog.mapper.table.BlogMapper;

public interface BlogService extends BaseDBService<Blog, BlogMapper> {
}

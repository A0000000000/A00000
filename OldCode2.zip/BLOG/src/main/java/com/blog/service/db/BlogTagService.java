package com.blog.service.db;


import com.blog.bean.orm.table.BlogTag;
import com.blog.mapper.table.BlogTagMapper;

import java.util.List;

public interface BlogTagService extends BaseDBService<BlogTag, BlogTagMapper> {

    List<BlogTag> selectUseBlogId(Integer id);

}

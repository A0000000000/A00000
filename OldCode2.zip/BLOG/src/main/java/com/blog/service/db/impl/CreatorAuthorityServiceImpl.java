package com.blog.service.db.impl;

import com.blog.bean.orm.table.CreatorAuthority;
import com.blog.mapper.table.CreatorAuthorityMapper;
import com.blog.service.db.CreatorAuthorityService;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class CreatorAuthorityServiceImpl extends BaseDBServiceImpl<CreatorAuthority, CreatorAuthorityMapper> implements CreatorAuthorityService {

}

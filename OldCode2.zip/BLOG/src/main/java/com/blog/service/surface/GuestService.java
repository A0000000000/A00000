package com.blog.service.surface;

import com.blog.bean.dto.BaseServiceResult;
import com.blog.bean.dto.PageBean;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.BlogComment;
import com.blog.bean.orm.table.BlogTag;
import com.blog.bean.orm.table.Friend;
import com.blog.bean.orm.table.Image;
import com.blog.bean.orm.view.BlogView;

import java.util.List;

/**
 * 访客操作的相关的业务层接口
 */
public interface GuestService {

    /**
     * 根据分页信息查询分页数据
     * @param form 分页信息
     * @return 分页数据
     */
    BaseServiceResult<PageBean<BlogView>> getBlogView(PageForm<BlogView> form);

    /**
     * 根据id获取博客
     * @param blogView 博客视图
     * @return 博客内容
     */
    BaseServiceResult<BlogView> getBlogView(BlogView blogView);

    /**
     * 查询图片的分页信息
     * @param form 图片的分页信息
     * @return 图片的分页结果
     */
    BaseServiceResult<PageBean<Image>> getImage(PageForm<Image> form);

    /**
     * 增加一条评论
     * @param blogComment 评论内容
     * @return 是否成功
     */
    BaseServiceResult<BlogComment> postBlogComment(BlogComment blogComment);

    /**
     * 增加联系方式
     * @param friend 联系方式
     * @return 是否成功
     */
    BaseServiceResult<Friend> postFriend(Friend friend);

    /**
     * 查询一条博客的标签
     * @param blogView 被查询的博客
     * @return 标签列表
     */
    BaseServiceResult<List<BlogTag>> getBlogTag(BlogView blogView);

}

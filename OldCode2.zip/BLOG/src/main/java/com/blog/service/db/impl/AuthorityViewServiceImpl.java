package com.blog.service.db.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.blog.bean.orm.view.AuthorityView;
import com.blog.mapper.view.AuthorityViewMapper;
import com.blog.service.db.AuthorityViewService;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 与操作AuthorityView相关的业务层实现类
 */
@Component
@Transactional
public class AuthorityViewServiceImpl extends BaseDBServiceImpl<AuthorityView, AuthorityViewMapper> implements AuthorityViewService {

    @Override
    public List<AuthorityView> selectUseCreatorId(Integer id) {
        QueryWrapper<AuthorityView> qw = new QueryWrapper<>();
        qw.eq("creator_id", id);
        return u.selectList(qw);
    }

}

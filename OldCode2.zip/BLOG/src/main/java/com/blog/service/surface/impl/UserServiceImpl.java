package com.blog.service.surface.impl;

import com.blog.bean.dto.BaseServiceResult;
import com.blog.bean.dto.PageBean;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.*;
import com.blog.bean.orm.view.BlogView;
import com.blog.bean.orm.view.UserView;
import com.blog.bean.other.MQJobBean;
import com.blog.service.db.*;
import com.blog.service.mq.ProviderService;
import com.blog.service.redis.JobDataService;
import com.blog.service.surface.UserService;
import com.blog.tools.constant.StaticConstant;
import com.blog.tools.utils.SecurityUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 用户操作的业务层接口的具体实现类
 */
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserViewService userViewService;
    @Autowired
    private CreatorService creatorService;
    @Autowired
    private CodeContrastService codeContrastService;
    @Autowired
    private CreatorInfoService creatorInfoService;
    @Autowired
    private BlogService blogService;
    @Autowired
    private BlogInfoService blogInfoService;
    @Autowired
    private BlogTypeService blogTypeService;
    @Autowired
    private BlogViewService blogViewService;
    @Autowired
    private BlogTagService blogTagService;
    @Autowired
    private ImageService imageService;
    @Autowired
    private FriendService friendService;
    @Autowired
    private ProviderService providerService;
    @Autowired
    private JobDataService jobDataService;
    @Autowired
    private PasswordEncoder encoder;

    @Override
    public BaseServiceResult<UserView> getUserView() {
        BaseServiceResult<UserView> res = new BaseServiceResult<>();
        try {
            UserView userView = userViewService.selectUseId(SecurityUtils.getAuthenticationUserId());
            userView.setPassword(null);
            res.setData(userView);
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<UserView> putUserView(UserView userView) {
        BaseServiceResult<UserView> res = new BaseServiceResult<>();
        try {
            userView.setId(SecurityUtils.getAuthenticationUserId());
            Creator currentCreator = creatorService.selectUseId(SecurityUtils.getAuthenticationUserId());
            CreatorInfo currentCreatorInfo = creatorInfoService.selectUseCreatorId(currentCreator.getId());
            if (!StringUtils.isEmpty(userView.getUsername())) {
                if (!userView.getUsername().equals(currentCreator.getUsername())) {
                    Creator creator = creatorService.selectUseUsername(userView.getUsername());
                    if (creator != null) {
                        throw new Exception(codeContrastService.selectUseName(StaticConstant.REPEAT_USERNAME).getValue());
                    }
                    currentCreator.setUsername(userView.getUsername());
                }
            }
            if (!StringUtils.isEmpty(userView.getPassword())) {
                currentCreator.setPassword(encoder.encode(userView.getPassword()));
            }
            if (!StringUtils.isEmpty(userView.getMessage())) {
                currentCreatorInfo.setMessage(userView.getMessage());
            }
            if (userView.getBirthday() != null) {
                currentCreatorInfo.setBirthday(userView.getBirthday());
            }
            Integer num = creatorService.update(currentCreator);
            if (num < 1) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
            num = creatorInfoService.update(currentCreatorInfo);
            if (num < 1) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
            BeanUtils.copyProperties(currentCreator, userView);
            BeanUtils.copyProperties(currentCreatorInfo, userView);
            userView.setPassword(null);
            res.setData(userView);
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<Void> deleteUserView() {
        BaseServiceResult<Void> res = new BaseServiceResult<>();
        try {
            CreatorInfo info = creatorInfoService.selectUseCreatorId(SecurityUtils.getAuthenticationUserId());
            info.setStatus(2);
            Integer num = creatorInfoService.update(info);
            if (num < 1) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<BlogView> postBlogView(BlogView blogView) {
        BaseServiceResult<BlogView> res = new BaseServiceResult<>();
        try {
            blogView.setCreateTime(new Date());
            blogView.setCreatorId(SecurityUtils.getAuthenticationUserId());
            Blog blog = new Blog();
            BeanUtils.copyProperties(blogView, blog);
            Integer num = blogService.insert(blog);
            if (num < 1) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
            blogView.setId(blog.getId());
            BlogType type = blogTypeService.selectUseTypeName(blogView.getTypeName());
            BlogInfo blogInfo = new BlogInfo();
            BeanUtils.copyProperties(blogView, blogInfo);
            blogInfo.setBlogId(blog.getId());
            blogInfo.setBlogTypeId(type.getId());
            num = blogInfoService.insert(blogInfo);
            if (num < 1) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
            res.setData(blogView);
            return res;
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<BlogView> putBlogView(BlogView blogView) {
        BaseServiceResult<BlogView> res = new BaseServiceResult<>();
        try {
            Blog blog = blogService.selectUseId(blogView.getId());
            BlogInfo blogInfo = blogInfoService.selectUseBlogId(blogView.getId());
            if (!ObjectUtils.nullSafeEquals(blogInfo.getCreatorId(), SecurityUtils.getAuthenticationUserId())) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.PERMISSION_DENIED).getValue());
            }
            if (!StringUtils.isEmpty(blogView.getTitle())) {
                blog.setTitle(blogView.getTitle());
            }
            if (!StringUtils.isEmpty(blogView.getContent())) {
                blog.setContent(blogView.getContent());
            }
            Integer num = blogService.update(blog);
            if (num < 1) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
            if (!StringUtils.isEmpty(blogView.getPassword())) {
                blogInfo.setPassword(blogView.getPassword());
            }
            if (!StringUtils.isEmpty(blogView.getTypeName())) {
                BlogType blogType = blogTypeService.selectUseTypeName(blogView.getTypeName());
                if (!ObjectUtils.nullSafeEquals(blogType.getId(), blogInfo.getBlogTypeId())) {
                    blogInfo.setBlogTypeId(blogType.getId());
                }
            }
            num = blogInfoService.update(blogInfo);
            if (num < 1) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
            res.setData(blogViewService.selectUseId(blog.getId()));
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<BlogType> postBlogType(BlogType blogType) {
        BaseServiceResult<BlogType> res = new BaseServiceResult<>();
        try {
            blogType.setCreatorId(SecurityUtils.getAuthenticationUserId());
            Integer num = blogTypeService.insert(blogType);
            if (num < 1) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
            res.setData(blogType);
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<Void> deleteBlogType(BlogType blogType) {
        BaseServiceResult<Void> res = new BaseServiceResult<>();
        try {
            BlogType currentBlogType = blogTypeService.selectUseId(blogType.getId());
            if (currentBlogType != null && currentBlogType.getCreatorId().equals(SecurityUtils.getAuthenticationUserId())) {
                Integer num = blogTypeService.delete(currentBlogType.getId());
                if (num < 1) {
                    throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
                }
            } else {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.PERMISSION_DENIED).getValue());
            }
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<PageBean<BlogType>> getBlogType(PageForm<BlogType> form) {
        BaseServiceResult<PageBean<BlogType>> res = new BaseServiceResult<>();
        try {
            Integer sum = blogTypeService.count();
            PageBean<BlogType> bean = PageBean.createPageBean(form, sum);
            List<BlogType> data = blogTypeService.selectUseForm(form);
            bean.setData(data);
            res.setData(bean);
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<BlogTag> postBlogTag(BlogTag blogTag) {
        BaseServiceResult<BlogTag> res = new BaseServiceResult<>();
        try {
            BlogView view = blogViewService.selectUseId(blogTag.getBlogId());
            if (!view.getCreatorId().equals(SecurityUtils.getAuthenticationUserId())) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.PERMISSION_DENIED).getValue());
            }
            blogTag.setCreatorId(SecurityUtils.getAuthenticationUserId());
            blogTag.setAddTime(new Date());
            Integer num = blogTagService.insert(blogTag);
            if (num < 1) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
            res.setData(blogTag);
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<Void> deleteBlogTag(BlogTag blogTag) {
        BaseServiceResult<Void> res = new BaseServiceResult<>();
        try {
            Integer num = blogTagService.delete(blogTag.getId());
            if (num < 1) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<List<Image>> postImage(MultipartFile[] images, Integer blogId) {
        BaseServiceResult<List<Image>> res = new BaseServiceResult<>();
        try {
            BlogView blogView = blogViewService.selectUseId(blogId);
            UserView userView = userViewService.selectUseId(SecurityUtils.getAuthenticationUserId());
            if (blogView.getCreatorId().equals(SecurityUtils.getAuthenticationUserId())) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.PERMISSION_DENIED).getValue());
            }
            List<Image> data = new ArrayList<>();
            AtomicBoolean flag = new AtomicBoolean(false);
            Map<String, MultipartFile> m = new HashMap<>();
            Arrays.stream(images).forEach(item -> {
                try {
                    Image image = new Image();
                    image.setPassword(blogView.getPassword());
                    image.setUploadTime(new Date());
                    image.setCreatorId(SecurityUtils.getAuthenticationUserId());
                    image.setBlogId(blogId);
                    image.setOriginalFilename(item.getOriginalFilename());
                    image.setFilename(UUID.randomUUID().toString());
                    Integer num = imageService.insert(image);
                    m.put(image.getFilename(), item);
                    if (num < 1) {
                        flag.set(true);
                    }
                    data.add(image);

                } catch (Exception ignore) { }
            });
            if (flag.get()) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
            MQJobBean bean = MQJobBean.getFileBean(String.format("%s\\%d", userView.getFileDirectory(), blogId), m);
            String message = jobDataService.addJobToRedis(bean);
            providerService.sendMessageToFile(message);
            res.setData(data);
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<Void> deleteImage(Image image) {
        BaseServiceResult<Void> res = new BaseServiceResult<>();
        try {
            image = imageService.selectUseId(image.getId());
            if (!image.getCreatorId().equals(SecurityUtils.getAuthenticationUserId())) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.PERMISSION_DENIED).getValue());
            }
            UserView userView = userViewService.selectUseId(image.getCreatorId());
            MQJobBean bean = new MQJobBean();
            bean.setType("delete");
            bean.setFolder(String.format("%s\\%s", userView.getFileDirectory(), image.getBlogId()));
            bean.setImage(image);
            String message = jobDataService.addJobToRedis(bean);
            providerService.sendMessageToFile(message);
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<PageBean<Friend>> getFriend(PageForm<Friend> form) {
        BaseServiceResult<PageBean<Friend>> res = new BaseServiceResult<>();
        try {
            if (form.getConditions() == null) {
                form.setConditions(new Friend());
            }
            form.getConditions().setCreatorId(SecurityUtils.getAuthenticationUserId());
            Integer sum = friendService.count();
            PageBean<Friend> bean = PageBean.createPageBean(form, sum);
            List<Friend> data = friendService.selectUseFrom(form);
            bean.setData(data);
            res.setData(bean);
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }
}

package com.blog.service.db.impl;

import com.blog.bean.orm.table.BlogComment;
import com.blog.mapper.table.BlogCommentMapper;
import com.blog.service.db.BlogCommentService;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class BlogCommentServiceImpl extends BaseDBServiceImpl<BlogComment, BlogCommentMapper> implements BlogCommentService {

}

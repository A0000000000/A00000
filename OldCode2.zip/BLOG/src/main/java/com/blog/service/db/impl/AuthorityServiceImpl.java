package com.blog.service.db.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.Authority;
import com.blog.mapper.table.AuthorityMapper;
import com.blog.service.db.AuthorityService;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 与操作Authority表相关的业务层实现类
 */
@Component
@Transactional
public class AuthorityServiceImpl extends BaseDBServiceImpl<Authority, AuthorityMapper> implements AuthorityService {

    @Override
    public List<Authority> selectUseForm(PageForm<Authority> form) {
        return u.selectByPage(form);
    }

    @Override
    public Authority selectUseAuthorityName(String authorityName) {
        QueryWrapper<Authority> qw = new QueryWrapper<>();
        qw.eq("authority_name", authorityName);
        return u.selectOne(qw);
    }
}

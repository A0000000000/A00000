package com.blog.service.db;

import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.view.BlogView;
import com.blog.mapper.view.BlogViewMapper;

import java.util.List;

public interface BlogViewService extends BaseDBService<BlogView, BlogViewMapper> {

    Integer count(Integer creatorId);

    List<BlogView> selectUseForm(PageForm<BlogView> form);

}

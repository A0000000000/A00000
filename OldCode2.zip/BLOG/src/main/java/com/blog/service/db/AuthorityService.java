package com.blog.service.db;

import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.Authority;
import com.blog.mapper.table.AuthorityMapper;

import java.util.List;

/**
 * 操作Authority表相关的业务层接口
 */
public interface AuthorityService extends BaseDBService<Authority, AuthorityMapper> {

    List<Authority> selectUseForm(PageForm<Authority> form);

    Authority selectUseAuthorityName(String authorityName);

}

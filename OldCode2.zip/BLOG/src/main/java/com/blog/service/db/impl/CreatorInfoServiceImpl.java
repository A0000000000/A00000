package com.blog.service.db.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.blog.bean.orm.table.CreatorInfo;
import com.blog.mapper.table.CreatorInfoMapper;
import com.blog.service.db.CreatorInfoService;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class CreatorInfoServiceImpl extends BaseDBServiceImpl<CreatorInfo, CreatorInfoMapper> implements CreatorInfoService {

    @Override
    public Integer updateUseCreatorId(CreatorInfo creatorInfo) {
        QueryWrapper<CreatorInfo> qw = new QueryWrapper<>();
        qw.eq("creator_id", creatorInfo.getCreatorId());
        return u.update(creatorInfo, qw);
    }

    @Override
    public CreatorInfo selectUseCreatorId(Integer id) {
        QueryWrapper<CreatorInfo> qw = new QueryWrapper<>();
        qw.eq("creator_id", id);
        return u.selectOne(qw);
    }

}

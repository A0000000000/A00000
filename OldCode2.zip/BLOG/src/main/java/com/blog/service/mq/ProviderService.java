package com.blog.service.mq;


/**
 * 操作RabbitMQ相关的业务层接口
 */
public interface ProviderService {

    void sendMessageToFile(String message);

    void sendMessageToEmail(String message);

}

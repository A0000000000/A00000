package com.blog.service.db;

import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.SystemConfig;
import com.blog.mapper.table.SystemConfigMapper;

import java.util.List;

/**
 * 操作SystemConfig表相关的业务层接口
 */
public interface SystemConfigService extends BaseDBService<SystemConfig, SystemConfigMapper> {

    /**
     * 通过配置名查询一条配置信息
     * @param name 配置名
     * @return SystemConfig数据对象
     */
    SystemConfig selectUseName(String name);

    /**
     * 通过分页信息查询系统配置
     * @param form 分页信息
     * @return 查询数据
     */
    List<SystemConfig> selectUseForm(PageForm<SystemConfig> form);

}

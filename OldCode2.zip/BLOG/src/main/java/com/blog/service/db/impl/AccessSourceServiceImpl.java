package com.blog.service.db.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.AccessSource;
import com.blog.mapper.table.AccessSourceMapper;
import com.blog.service.db.AccessSourceService;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 与AccessSource表操作相关的业务层实现类
 */
@Component
@Transactional
public class AccessSourceServiceImpl extends BaseDBServiceImpl<AccessSource, AccessSourceMapper> implements AccessSourceService {

    @Override
    public AccessSource selectUseName(String source) {
        QueryWrapper<AccessSource> qw = new QueryWrapper<>();
        qw.eq("name", source);
        return u.selectOne(qw);
    }

    @Override
    public List<AccessSource> selectUseForm(PageForm<AccessSource> form) {
        return u.selectByPage(form);
    }

}

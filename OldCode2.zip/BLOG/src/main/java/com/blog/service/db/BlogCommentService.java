package com.blog.service.db;

import com.blog.bean.orm.table.BlogComment;
import com.blog.mapper.table.BlogCommentMapper;

public interface BlogCommentService extends BaseDBService<BlogComment, BlogCommentMapper> {
}

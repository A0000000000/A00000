package com.blog.service.db;

import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.view.UserView;
import com.blog.mapper.view.UserViewMapper;

import java.util.List;

/**
 * 操作UserView表相关的业务层接口
 */
public interface UserViewService extends BaseDBService<UserView, UserViewMapper> {

    /**
     * 通过用户名查询一条用户信息
     * @param username 用户名
     * @return 用户信息
     */
    UserView selectUseUsername(String username);

    /**
     * 通过分页信息查询数据
     * @param form 分页条件
     * @return 分页结果
     */
    List<UserView> selectUseForm(PageForm<UserView> form);

}

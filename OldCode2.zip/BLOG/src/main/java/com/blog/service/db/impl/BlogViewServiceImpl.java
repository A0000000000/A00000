package com.blog.service.db.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.view.BlogView;
import com.blog.mapper.view.BlogViewMapper;
import com.blog.service.db.BlogViewService;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component
@Transactional
public class BlogViewServiceImpl extends BaseDBServiceImpl<BlogView, BlogViewMapper> implements BlogViewService {
    @Override
    public Integer count(Integer creatorId) {
        QueryWrapper<BlogView> qw = new QueryWrapper<>();
        qw.eq("creator_id", creatorId);
        return u.selectCount(qw);
    }

    @Override
    public List<BlogView> selectUseForm(PageForm<BlogView> form) {
        return u.selectByPage(form);
    }
}

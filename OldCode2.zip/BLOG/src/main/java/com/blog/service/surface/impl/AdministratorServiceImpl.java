package com.blog.service.surface.impl;

import com.blog.bean.dto.BaseServiceResult;
import com.blog.bean.dto.PageBean;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.*;
import com.blog.bean.orm.view.AuthorityView;
import com.blog.bean.orm.view.UserView;
import com.blog.service.db.*;
import com.blog.service.surface.AdministratorService;
import com.blog.tools.constant.StaticConstant;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Date;
import java.util.List;

/**
 * 管理员操作的接口的具体实现类
 */
@Service
public class AdministratorServiceImpl implements AdministratorService {

    @Autowired
    private LogService logService;
    @Autowired
    private AccessInfoService accessInfoService;
    @Autowired
    private CodeContrastService codeContrastService;
    @Autowired
    private AccessSourceService accessSourceService;
    @Autowired
    private SystemConfigService systemConfigService;
    @Autowired
    private AuthorityService authorityService;
    @Autowired
    private UserViewService userViewService;
    @Autowired
    private CreatorService creatorService;
    @Autowired
    private CreatorInfoService creatorInfoService;
    @Autowired
    private CreatorAuthorityService creatorAuthorityService;
    @Autowired
    private AuthorityViewService authorityViewService;

    @Override
    public BaseServiceResult<PageBean<Log>> getSystemLog(PageForm<Log> form) {
        BaseServiceResult<PageBean<Log>> res = new BaseServiceResult<>();
        try {
            Integer sum = logService.count();
            PageBean<Log> bean = PageBean.createPageBean(form, sum);
            List<Log> logs = logService.selectUseForm(form);
            bean.setData(logs);
            res.setData(bean);
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<PageBean<AccessInfo>> getAccessInfo(PageForm<AccessInfo> form) {
        BaseServiceResult<PageBean<AccessInfo>> res = new BaseServiceResult<>();
        try {
            Integer sum = accessInfoService.count();
            PageBean<AccessInfo> bean = PageBean.createPageBean(form, sum);
            List<AccessInfo> accessInfos = accessInfoService.selectUseForm(form);
            bean.setData(accessInfos);
            res.setData(bean);
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<PageBean<CodeContrast>> getCodeContrast(PageForm<CodeContrast> form) {
        BaseServiceResult<PageBean<CodeContrast>> res = new BaseServiceResult<>();
        try {
            Integer sum = codeContrastService.count();
            PageBean<CodeContrast> bean = PageBean.createPageBean(form, sum);
            List<CodeContrast> codeContrasts = codeContrastService.selectUseForm(form);
            bean.setData(codeContrasts);
            res.setData(bean);
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<CodeContrast> postCodeContrast(CodeContrast codeContrast) {
        BaseServiceResult<CodeContrast> res = new BaseServiceResult<>();
        try {
            if (StringUtils.isEmpty(codeContrast.getName()) || StringUtils.isEmpty(codeContrast.getValue())) {
                res.setE(new Exception(codeContrastService.selectUseName(StaticConstant.EMPTY_ARGS).getValue()));
            } else {
                Integer num = codeContrastService.insert(codeContrast);
                if (num > 0) {
                    res.setData(codeContrast);
                } else {
                    res.setE(new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue()));
                }
            }
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<Void> deleteCodeContrast(CodeContrast codeContrast) {
        BaseServiceResult<Void> res = new BaseServiceResult<>();
        try {
            Integer num = codeContrastService.delete(codeContrast.getId());
            if (num <= 0) {
                res.setE(new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue()));
            }
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<PageBean<AccessSource>> getAccessSource(PageForm<AccessSource> form) {
        BaseServiceResult<PageBean<AccessSource>> res = new BaseServiceResult<>();
        try {
            Integer sum = accessSourceService.count();
            PageBean<AccessSource> bean = PageBean.createPageBean(form, sum);
            List<AccessSource> data = accessSourceService.selectUseForm(form);
            bean.setData(data);
            res.setData(bean);
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<AccessSource> postAccessSource(AccessSource accessSource) {
        BaseServiceResult<AccessSource> res = new BaseServiceResult<>();
        try {
            if (StringUtils.isEmpty(accessSource.getName())) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.EMPTY_ARGS).getValue());
            }
            Integer num = accessSourceService.insert(accessSource);
            if (num > 0) {
                res.setData(accessSource);
            } else {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<Void> deleteAccessSource(AccessSource accessSource) {
        BaseServiceResult<Void> res = BaseServiceResult.getSuccessBean(null);
        try {
            Integer num = accessSourceService.delete(accessSource.getId());
            if (num <= 0) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<PageBean<SystemConfig>> getSystemConfig(PageForm<SystemConfig> form) {
        BaseServiceResult<PageBean<SystemConfig>> res = new BaseServiceResult<>();
        try {
            Integer sum = systemConfigService.count();
            PageBean<SystemConfig> bean = PageBean.createPageBean(form, sum);
            List<SystemConfig> systemConfigs = systemConfigService.selectUseForm(form);
            bean.setData(systemConfigs);
            res.setData(bean);
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<SystemConfig> postSystemConfig(SystemConfig systemConfig) {
        BaseServiceResult<SystemConfig> res = new BaseServiceResult<>();
        try {
            Integer num = systemConfigService.insert(systemConfig);
            if (num > 0) {
                res.setData(systemConfig);
            } else {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<SystemConfig> putSystemConfig(SystemConfig systemConfig) {
        BaseServiceResult<SystemConfig> res = new BaseServiceResult<>();
        try {
            Integer num = systemConfigService.update(systemConfig);
            if (num > 0) {
                res.setData(systemConfig);
            } else {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<Void> deleteSystemConfig(SystemConfig systemConfig) {
        BaseServiceResult<Void> res = new BaseServiceResult<>();
        try {
            Integer num = systemConfigService.delete(systemConfig.getId());
            if (num <= 0) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<PageBean<Authority>> getAuthority(PageForm<Authority> form) {
        BaseServiceResult<PageBean<Authority>> res = new BaseServiceResult<>();
        try {
            Integer sum = authorityService.count();
            PageBean<Authority> bean = PageBean.createPageBean(form, sum);
            List<Authority> authorities = authorityService.selectUseForm(form);
            bean.setData(authorities);
            res.setData(bean);
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<PageBean<UserView>> getUserView(PageForm<UserView> form) {
        BaseServiceResult<PageBean<UserView>> res = new BaseServiceResult<>();
        try {
            Integer sum = userViewService.count();
            PageBean<UserView> bean = PageBean.createPageBean(form, sum);
            List<UserView> userViews = userViewService.selectUseForm(form);
            userViews.forEach(item -> item.setPassword(null));
            bean.setData(userViews);
            res.setData(bean);
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<UserView> postUserView(UserView userView) {
        BaseServiceResult<UserView> res = new BaseServiceResult<>();
        try {
            if (StringUtils.isEmpty(userView.getUsername()) || StringUtils.isEmpty(userView.getPassword())) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.PARAMETER_ERROR).getValue());
            }
            Creator tmp = creatorService.selectUseUsername(userView.getUsername());
            if (tmp != null) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.REPEAT_USERNAME).getValue());
            }
            userView.setCreateTime(new Date());
            if (StringUtils.isEmpty(userView.getFileDirectory())) {
                userView.setFileDirectory(userView.getUsername());
            }
            if (userView.getStatus() == null) {
                userView.setStatus(0);
            }
            Creator creator = new Creator();
            BeanUtils.copyProperties(userView, creator);
            Integer num = creatorService.insert(creator);
            if (num < 1) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
            Authority authority = authorityService.selectUseAuthorityName("ROLE_USER");
            CreatorAuthority creatorAuthority = new CreatorAuthority();
            creatorAuthority.setCreatorId(creator.getId());
            creatorAuthority.setAuthorityId(authority.getId());
            num = creatorAuthorityService.insert(creatorAuthority);
            if (num < 1) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
            CreatorInfo creatorInfo = new CreatorInfo();
            BeanUtils.copyProperties(userView, creatorInfo);
            creatorInfo.setCreatorId(creator.getId());
            userView.setId(creator.getId());
            userView.setPassword(null);
            num = creatorInfoService.insert(creatorInfo);
            if (num < 1) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
            res.setData(userView);
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<UserView> putUserView(UserView userView) {
        BaseServiceResult<UserView> res = new BaseServiceResult<>();
        try {
            List<AuthorityView> list = authorityViewService.selectUseCreatorId(userView.getId());
            for (AuthorityView view : list) {
                if ("ROLE_ADMIN".equals(view.getAuthorityName())) {
                    throw new Exception(codeContrastService.selectUseName(StaticConstant.PERMISSION_DENIED).getValue());
                }
            }
            CreatorInfo creatorInfo = new CreatorInfo();
            BeanUtils.copyProperties(userView, creatorInfo);
            creatorInfo.setCreatorId(userView.getId());
            creatorInfo.setId(null);
            Integer num = creatorInfoService.updateUseCreatorId(creatorInfo);
            if (num < 1) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
            res.setData(userView);
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<CreatorAuthority> postCreatorAuthority(CreatorAuthority creatorAuthority) {
        BaseServiceResult<CreatorAuthority> result = new BaseServiceResult<>();
        try {
            Integer num = creatorAuthorityService.insert(creatorAuthority);
            if (num < 1) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
            result.setData(creatorAuthority);
        } catch (Exception e) {
            result.setE(e);
        }
        return result;
    }

    @Override
    public BaseServiceResult<Void> deleteCreatorAuthority(CreatorAuthority creatorAuthority) {
        BaseServiceResult<Void> result = new BaseServiceResult<>();
        try {
            Integer num = creatorAuthorityService.delete(creatorAuthority.getId());
            if (num < 1) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
        } catch (Exception e) {
            result.setE(e);
        }
        return result;
    }
}

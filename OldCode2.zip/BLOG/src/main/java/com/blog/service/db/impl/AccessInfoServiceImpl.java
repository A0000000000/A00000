package com.blog.service.db.impl;

import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.AccessInfo;
import com.blog.mapper.table.AccessInfoMapper;
import com.blog.service.db.AccessInfoService;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 与AccessInfo表操作相关的业务层实现类
 */
@Component
@Transactional
public class AccessInfoServiceImpl extends BaseDBServiceImpl<AccessInfo, AccessInfoMapper> implements AccessInfoService {

    @Override
    public List<AccessInfo> selectUseForm(PageForm<AccessInfo> form) {
        return u.selectByPage(form);
    }

}

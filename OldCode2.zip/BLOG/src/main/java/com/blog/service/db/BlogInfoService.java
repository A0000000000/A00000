package com.blog.service.db;

import com.blog.bean.orm.table.BlogInfo;
import com.blog.mapper.table.BlogInfoMapper;

public interface BlogInfoService extends BaseDBService<BlogInfo, BlogInfoMapper> {

    BlogInfo selectUseBlogId(Integer id);

}

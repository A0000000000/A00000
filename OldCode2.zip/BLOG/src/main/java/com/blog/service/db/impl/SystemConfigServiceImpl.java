package com.blog.service.db.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.SystemConfig;
import com.blog.mapper.table.SystemConfigMapper;
import com.blog.service.db.SystemConfigService;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component
@Transactional
public class SystemConfigServiceImpl extends BaseDBServiceImpl<SystemConfig, SystemConfigMapper> implements SystemConfigService {

    @Override
    public SystemConfig selectUseName(String name) {
        QueryWrapper<SystemConfig> qw = new QueryWrapper<>();
        qw.eq("name", name);
        return u.selectOne(qw);
    }

    @Override
    public List<SystemConfig> selectUseForm(PageForm<SystemConfig> form) {
        return u.selectByPage(form);
    }

}

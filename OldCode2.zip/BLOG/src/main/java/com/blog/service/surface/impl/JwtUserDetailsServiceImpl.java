package com.blog.service.surface.impl;

import com.blog.bean.orm.view.AuthorityView;
import com.blog.bean.orm.view.UserView;
import com.blog.service.db.AuthorityViewService;
import com.blog.service.db.UserViewService;
import com.blog.tools.factory.JwtUserFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 与Spring Security身份认证相关的业务层
 */
@Service("jwtUserDetailsServiceImpl")
public class JwtUserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    private UserViewService userViewService;
    @Autowired
    private AuthorityViewService authorityViewService;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        UserView userView = userViewService.selectUseUsername(username);
        if (userView.getStatus() != null && userView.getStatus() != 0) {
            return null;
        }
        List<AuthorityView> authorityViews = authorityViewService.selectUseCreatorId(userView.getId());
        return JwtUserFactory.createJwtUser(userView, authorityViews);
    }
}

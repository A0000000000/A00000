package com.blog.service.db;

import com.blog.bean.orm.table.CreatorAuthority;
import com.blog.mapper.table.CreatorAuthorityMapper;

public interface CreatorAuthorityService extends BaseDBService<CreatorAuthority, CreatorAuthorityMapper> {
}

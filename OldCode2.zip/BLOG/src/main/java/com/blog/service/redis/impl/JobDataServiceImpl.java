package com.blog.service.redis.impl;

import com.blog.bean.exception.RedisException;
import com.blog.bean.other.MQJobBean;
import com.blog.service.redis.JobDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class JobDataServiceImpl implements JobDataService {

    @Autowired
    private RedisTemplate<String, MQJobBean> redisTemplate;

    @Override
    public String addJobToRedis(MQJobBean bean) {
        try {
            ValueOperations<String, MQJobBean> ops = redisTemplate.opsForValue();
            String guid = UUID.randomUUID().toString();
            while (redisTemplate.hasKey(guid)) {
                guid = UUID.randomUUID().toString();
            }
            ops.set(guid, bean);
            return guid;
        } catch (Exception e) {
            throw new RedisException(e);
        }
    }

    @Override
    public MQJobBean getJobFromRedis(String key) {
        try {
            if (!redisTemplate.hasKey(key)) {
                return null;
            }
            ValueOperations<String, MQJobBean> ops = redisTemplate.opsForValue();
            return ops.get(key);
        } catch (Exception e) {
            throw new RedisException(e);
        }
    }

    @Override
    public Boolean removeJobFromRedis(String key) {
        try {
            if (!redisTemplate.hasKey(key)) {
                return false;
            } else {
                return redisTemplate.delete(key);
            }
        } catch (Exception e) {
            throw new RedisException(e);
        }
    }

    @Override
    public Boolean hasJobInRedis(String key) {
        try {
            return redisTemplate.hasKey(key);
        } catch (Exception e) {
            throw new RedisException(e);
        }
    }

}

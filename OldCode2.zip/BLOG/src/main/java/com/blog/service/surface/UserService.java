package com.blog.service.surface;

import com.blog.bean.dto.BaseServiceResult;
import com.blog.bean.dto.PageBean;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.*;
import com.blog.bean.orm.view.BlogView;
import com.blog.bean.orm.view.UserView;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 用户操作的相关的业务层接口
 */
public interface UserService {

    /**
     * 获取当前用户的信息
     * @return 当前用户信息
     */
    BaseServiceResult<UserView> getUserView();

    /**
     * 更新用户信息
     * @param userView 用户信息视图
     * @return 是否更新成功
     */
    BaseServiceResult<UserView> putUserView(UserView userView);

    /**
     * 注销账户
     * @return 修改账户状态
     */
    BaseServiceResult<Void> deleteUserView();

    /**
     * 初始化一篇博客
     * @param blogView 被初始化内容
     * @return
     */
    BaseServiceResult<BlogView> postBlogView(BlogView blogView);

    /**
     * 更新博客
     * @param blogView 待更新博客
     * @return 更新后的博客
     */
    BaseServiceResult<BlogView> putBlogView(BlogView blogView);

    /**
     * 添加标签
     * @param blogType 博客标签
     * @return 带主键id的博客标签
     */
    BaseServiceResult<BlogType> postBlogType(BlogType blogType);

    /**
     * 删除标签
     * @param blogType 待删除标签
     * @return 是否成功
     */
    BaseServiceResult<Void> deleteBlogType(BlogType blogType);

    /**
     * 分页查询标签列表
     * @param form 分页数据
     * @return 标题列表
     */
    BaseServiceResult<PageBean<BlogType>> getBlogType(PageForm<BlogType> form);

    /**
     * 向博客增加一个标签
     * @param blogTag 博客标签
     * @return 带主键的标签信息
     */
    BaseServiceResult<BlogTag> postBlogTag(BlogTag blogTag);

    /**
     * 删除一个标签
     * @param blogTag 博客标签
     * @return 是否删除成功
     */
    BaseServiceResult<Void> deleteBlogTag(BlogTag blogTag);

    /**
     * 上传图片
     * @param images 待报错的图片数据
     * @param blogId 需要图片的博客
     * @return 上传后的图片
     */
    BaseServiceResult<List<Image>> postImage(MultipartFile[] images, Integer blogId);

    /**
     * 删除一张图片
     * @param image 图片信息
     * @return 是否删除成功
     */
    BaseServiceResult<Void> deleteImage(Image image);

    /**
     * 获得联系方式
     * @param form 分页信息
     * @return 结果
     */
    BaseServiceResult<PageBean<Friend>> getFriend(PageForm<Friend> form);

}

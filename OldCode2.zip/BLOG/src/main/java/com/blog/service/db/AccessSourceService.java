package com.blog.service.db;

import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.AccessSource;
import com.blog.mapper.table.AccessSourceMapper;

import java.util.List;

/**
 * 操作AccessSource表相关的业务层接口
 */
public interface AccessSourceService extends BaseDBService<AccessSource, AccessSourceMapper> {

    /**
     * 通过source值获得AccessSource的一条记录
     * @param source 值
     * @return AccessSource数据对象
     */
    AccessSource selectUseName(String source);

    /**
     * 通过分页信息, 查询分页结果
     * @param form 分页信息
     * @return 分页结果
     */
    List<AccessSource> selectUseForm(PageForm<AccessSource> form);


}

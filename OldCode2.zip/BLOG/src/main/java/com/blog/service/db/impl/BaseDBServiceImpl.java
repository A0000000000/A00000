package com.blog.service.db.impl;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.blog.service.db.BaseDBService;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.Serializable;

public class BaseDBServiceImpl<T, U extends BaseMapper<T>> implements BaseDBService<T, U> {

    @Autowired
    @SuppressWarnings("SpringJavaInjectionPointsAutowiringInspection")
    protected U u;

    @Override
    public Integer insert(T t) {
        return u.insert(t);
    }

    @Override
    public Integer update(T t) {
        return u.updateById(t);
    }

    @Override
    public Integer delete(Serializable id) {
        return u.deleteById(id);
    }

    @Override
    public Integer count() {
        return u.selectCount(null);
    }

    @Override
    public T selectUseId(Serializable id) {
        return u.selectById(id);
    }

}

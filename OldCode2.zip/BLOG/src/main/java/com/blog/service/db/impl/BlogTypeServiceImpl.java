package com.blog.service.db.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.BlogType;
import com.blog.mapper.table.BlogTypeMapper;
import com.blog.service.db.BlogTypeService;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component
@Transactional
public class BlogTypeServiceImpl extends BaseDBServiceImpl<BlogType, BlogTypeMapper> implements BlogTypeService {
    @Override
    public BlogType selectUseTypeName(String typeName) {
        QueryWrapper<BlogType> qw = new QueryWrapper<>();
        qw.eq("type_name", typeName);
        return u.selectOne(qw);
    }

    @Override
    public List<BlogType> selectUseForm(PageForm<BlogType> form) {
        return u.selectByPage(form);
    }
}

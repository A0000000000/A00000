package com.blog.service.db.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.view.UserView;
import com.blog.mapper.view.UserViewMapper;
import com.blog.service.db.UserViewService;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 操作UserView表相关的业务层接口实现类
 */
@Component
@Transactional
public class UserViewServiceImpl extends BaseDBServiceImpl<UserView, UserViewMapper> implements UserViewService {

    @Override
    public UserView selectUseUsername(String username) {
        QueryWrapper<UserView> qw = new QueryWrapper<>();
        qw.eq("username", username);
        return u.selectOne(qw);
    }

    @Override
    public List<UserView> selectUseForm(PageForm<UserView> form) {
        return u.selectByPage(form);
    }

}

package com.blog.service.db;

import com.blog.bean.orm.table.CreatorInfo;
import com.blog.mapper.table.CreatorInfoMapper;

public interface CreatorInfoService extends BaseDBService<CreatorInfo, CreatorInfoMapper> {

    Integer updateUseCreatorId(CreatorInfo creatorInfo);

    CreatorInfo selectUseCreatorId(Integer id);

}

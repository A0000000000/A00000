package com.blog.service.db;

import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.AccessInfo;
import com.blog.mapper.table.AccessInfoMapper;

import java.util.List;

/**
 * 操作AccessInfo表相关的业务层接口
 */
public interface AccessInfoService extends BaseDBService<AccessInfo, AccessInfoMapper> {

    /**
     * 根据分页条件, 查询分页信息
     * @param form 分页条件
     * @return 查询结果
     */
    List<AccessInfo> selectUseForm(PageForm<AccessInfo> form);

}

package com.blog.service.db.impl;

import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.Friend;
import com.blog.mapper.table.FriendMapper;
import com.blog.service.db.FriendService;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component
@Transactional
public class FriendServiceImpl extends BaseDBServiceImpl<Friend, FriendMapper> implements FriendService {
    @Override
    public List<Friend> selectUseFrom(PageForm<Friend> form) {
        return u.selectByPage(form);
    }
}

package com.blog.service.db;

import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.CodeContrast;
import com.blog.mapper.table.CodeContrastMapper;

import java.util.List;

/**
 * 操作CodeContrast表相关的业务层接口
 */
public interface CodeContrastService extends BaseDBService<CodeContrast, CodeContrastMapper> {

    /**
     * 通过名字查询CodeContrast数据
     * @param name 名字
     * @return CodeContrast数据对象
     */
    CodeContrast selectUseName(String name);

    /**
     * 根据分页条件查询分页信息
     * @param form 分页条件
     * @return 查询结果
     */
    List<CodeContrast> selectUseForm(PageForm<CodeContrast> form);


}

package com.blog.service.surface.impl;


import com.blog.bean.dto.BaseServiceResult;
import com.blog.bean.dto.PageBean;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.*;
import com.blog.bean.orm.view.BlogView;
import com.blog.service.db.*;
import com.blog.service.surface.GuestService;
import com.blog.tools.constant.StaticConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Date;
import java.util.List;

/**
 * 访客操作的业务层的具体实现类
 */
@Service
public class GuestServiceImpl implements GuestService {

    @Autowired
    private BlogViewService blogViewService;
    @Autowired
    private CodeContrastService codeContrastService;
    @Autowired
    private ImageService imageService;
    @Autowired
    private BlogCommentService blogCommentService;
    @Autowired
    private FriendService friendService;
    @Autowired
    private BlogTagService blogTagService;

    @Override
    public BaseServiceResult<PageBean<BlogView>> getBlogView(PageForm<BlogView> form) {
        BaseServiceResult<PageBean<BlogView>> res = new BaseServiceResult<>();
        try {
            if (form.getConditions().getCreatorId() == null) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.PARAMETER_ERROR).getValue());
            }
            Integer sum = blogViewService.count(form.getConditions().getCreatorId());
            PageBean<BlogView> bean = PageBean.createPageBean(form, sum);
            List<BlogView> data = blogViewService.selectUseForm(form);
            data.forEach(item -> {
                item.setContent(null);
                item.setPassword(item.getPassword() == null ? "false" : "true");
            });
            res.setData(bean);
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<BlogView> getBlogView(BlogView blogView) {
        BaseServiceResult<BlogView> res = new BaseServiceResult<>();
        try {
            if (blogView.getId() == null) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.PARAMETER_ERROR).getValue());
            }
            BlogView currentBlogView = blogViewService.selectUseId(blogView.getId());
            if (StringUtils.isEmpty(currentBlogView.getPassword()) || currentBlogView.getPassword().equals(blogView.getPassword())) {
                currentBlogView.setPassword(null);
                res.setData(currentBlogView);
            } else {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.PERMISSION_DENIED).getValue());
            }
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<PageBean<Image>> getImage(PageForm<Image> form) {
        BaseServiceResult<PageBean<Image>> res = new BaseServiceResult<>();
        try {
            Integer sum = imageService.count(form.getConditions());
            PageBean<Image> bean = PageBean.createPageBean(form, sum);
            List<Image> data = imageService.selectUseForm(form);
            data.forEach(item -> {
                item.setPassword(null);
            });
            bean.setData(data);
            res.setData(bean);
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<BlogComment> postBlogComment(BlogComment blogComment) {
        BaseServiceResult<BlogComment> res = new BaseServiceResult<>();
        try {
            if (StringUtils.isEmpty(blogComment.getBlogId()) || StringUtils.isEmpty(blogComment.getNickname())) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.PARAMETER_ERROR).getValue());
            }
            blogComment.setStatus(0);
            blogComment.setCommentTime(new Date());
            Integer num = blogCommentService.insert(blogComment);
            if (num < 1) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
            res.setData(blogComment);
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<Friend> postFriend(Friend friend) {
        BaseServiceResult<Friend> res = new BaseServiceResult<>();
        try {
            if (StringUtils.isEmpty(friend.getBlogId())) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.PARAMETER_ERROR).getValue());
            }
            BlogView view = blogViewService.selectUseId(friend.getBlogId());
            friend.setCreatorId(view.getCreatorId());
            friend.setSubmitTime(new Date());
            Integer num = friendService.insert(friend);
            if (num < 1) {
                throw new Exception(codeContrastService.selectUseName(StaticConstant.SERVER_ERROR).getValue());
            }
            res.setData(friend);
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }

    @Override
    public BaseServiceResult<List<BlogTag>> getBlogTag(BlogView blogView) {
        BaseServiceResult<List<BlogTag>> res = new BaseServiceResult<>();
        try {
            List<BlogTag> data = blogTagService.selectUseBlogId(blogView.getId());
            res.setData(data);
        } catch (Exception e) {
            res.setE(e);
        }
        return res;
    }
}

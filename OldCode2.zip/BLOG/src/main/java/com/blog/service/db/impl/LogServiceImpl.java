package com.blog.service.db.impl;

import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.Log;
import com.blog.mapper.table.LogMapper;
import com.blog.service.db.LogService;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 操作Log表相关的业务层接口的实现类
 */
@Component
@Transactional
public class LogServiceImpl extends BaseDBServiceImpl<Log, LogMapper> implements LogService {

    @Override
    public List<Log> selectUseForm(PageForm<Log> form) {
        return u.selectByPage(form);
    }

}

package com.blog.service.db.impl;

import com.blog.bean.orm.table.Blog;
import com.blog.mapper.table.BlogMapper;
import com.blog.service.db.BlogService;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class BlogServiceImpl extends BaseDBServiceImpl<Blog, BlogMapper> implements BlogService {

}

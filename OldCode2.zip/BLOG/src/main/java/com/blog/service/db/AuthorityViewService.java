package com.blog.service.db;

import com.blog.bean.orm.view.AuthorityView;
import com.blog.mapper.view.AuthorityViewMapper;

import java.util.List;

/**
 * 操作AuthorityView表相关的业务层接口
 */
public interface AuthorityViewService extends BaseDBService<AuthorityView, AuthorityViewMapper> {

    /**
     * 通过用户id查询用户所具有的身份
     * @param id 用户id
     * @return 身份列表
     */
    List<AuthorityView> selectUseCreatorId(Integer id);

}

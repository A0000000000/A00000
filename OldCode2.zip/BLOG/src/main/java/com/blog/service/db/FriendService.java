package com.blog.service.db;

import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.Friend;
import com.blog.mapper.table.FriendMapper;

import java.util.List;

public interface FriendService extends BaseDBService<Friend, FriendMapper> {

    List<Friend> selectUseFrom(PageForm<Friend> form);

}

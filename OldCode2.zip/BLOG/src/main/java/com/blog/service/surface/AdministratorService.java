package com.blog.service.surface;

import com.blog.bean.dto.BaseServiceResult;
import com.blog.bean.dto.PageBean;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.*;
import com.blog.bean.orm.view.UserView;

/**
 * 管理员操作相关的业务层接口
 */
public interface AdministratorService {

    /**
     * 根据分页信息, 查询日志
     * @param form 分页条件
     * @return 分页结果
     */
    BaseServiceResult<PageBean<Log>> getSystemLog(PageForm<Log> form);

    /**
     * 查询系统的访问信息
     * @param form 查询条件
     * @return 查询结果
     */
    BaseServiceResult<PageBean<AccessInfo>> getAccessInfo(PageForm<AccessInfo> form);

    /**
     * 查询错误对照表
     * @param form 查询条件
     * @return 查询结果
     */
    BaseServiceResult<PageBean<CodeContrast>> getCodeContrast(PageForm<CodeContrast> form);

    /**
     * 插入一条新的错误对照记录
     * @param codeContrast 记录
     * @return 是否插入成功
     */
    BaseServiceResult<CodeContrast> postCodeContrast(CodeContrast codeContrast);

    /**
     * 根据封装的id属性删除一条记录
     * @param codeContrast 被封装的对象
     * @return 是否删除成功
     */
    BaseServiceResult<Void> deleteCodeContrast(CodeContrast codeContrast);

    /**
     * 根据分页信息查询分页数据
     * @param form 分页信息
     * @return 分页数据
     */
    BaseServiceResult<PageBean<AccessSource>> getAccessSource(PageForm<AccessSource> form);

    /**
     * 添加一条新的记录
     * @param accessSource 待添加记录
     * @return 返回结果
     */
    BaseServiceResult<AccessSource> postAccessSource(AccessSource accessSource);

    /**
     * 移除一条记录
     * @param accessSource
     * @return
     */
    BaseServiceResult<Void> deleteAccessSource(AccessSource accessSource);

    /**
     * 根据分页信息查询系统配置
     * @param form 分页信息
     * @return 系统配置
     */
    BaseServiceResult<PageBean<SystemConfig>> getSystemConfig(PageForm<SystemConfig> form);

    /**
     * 添加一条新配置
     * @param systemConfig 配置信息
     * @return 含主键的配置信息
     */
    BaseServiceResult<SystemConfig> postSystemConfig(SystemConfig systemConfig);

    /**
     * 更新一条系统配置
     * @param systemConfig 系统配置信息
     * @return 修改后的系统配置信息
     */
    BaseServiceResult<SystemConfig> putSystemConfig(SystemConfig systemConfig);

    /**
     * 删除一条系统配置
     * @param systemConfig 待删除的系统配置
     * @return 是否成功
     */
    BaseServiceResult<Void> deleteSystemConfig(SystemConfig systemConfig);

    /**
     * 根据分页信息查询身份列表
     * @param form 分页信息
     * @return 结果视图
     */
    BaseServiceResult<PageBean<Authority>> getAuthority(PageForm<Authority> form);

    /**
     * 根据分页信息查询用户视图
     * @param form 分页信息
     * @return 结果视图
     */
    BaseServiceResult<PageBean<UserView>> getUserView(PageForm<UserView> form);

    /**
     * 根据用户视图信息, 增加一条用户, 用户详情
     * @param userView 用户视图信息
     * @return 增加后的用户视图信息
     */
    BaseServiceResult<UserView> postUserView(UserView userView);

    /**
     * 更新用户状态, (可以更新用户名, 密码之外的其他操作, 但是不建议使用)
     * @param userView 待更新的用户视图
     * @return 更新后的用户视图
     */
    BaseServiceResult<UserView> putUserView(UserView userView);

    /**
     * 授予用户权限
     * @param creatorAuthority 用户与权限id
     * @return 插入主键后的结果
     */
    BaseServiceResult<CreatorAuthority> postCreatorAuthority(CreatorAuthority creatorAuthority);

    /**
     * 移除用户权限
     * @param creatorAuthority 用户权限
     * @return 是否成功
     */
    BaseServiceResult<Void> deleteCreatorAuthority(CreatorAuthority creatorAuthority);

}

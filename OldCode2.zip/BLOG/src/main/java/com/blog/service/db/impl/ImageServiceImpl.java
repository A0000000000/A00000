package com.blog.service.db.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.Image;
import com.blog.mapper.table.ImageMapper;
import com.blog.service.db.ImageService;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.List;

@Component
@Transactional
public class ImageServiceImpl extends BaseDBServiceImpl<Image, ImageMapper> implements ImageService {
    @Override
    public Integer count(Image conditions) {
        if (conditions == null) {
            return super.count();
        }
        QueryWrapper<Image> qw = new QueryWrapper<>();
        if (conditions.getId() != null) {
            qw.eq("id", conditions.getId());
        }
        if (conditions.getBlogId() != null) {
            qw.eq("blog_id", conditions.getBlogId());
        }
        if (conditions.getCreatorId() != null) {
            qw.eq("creator_id", conditions.getCreatorId());
        }
        if (!StringUtils.isEmpty(conditions.getOriginalFilename())) {
            qw.like("original_filename", "%" + conditions.getOriginalFilename() + "%");
        }
        if (!StringUtils.isEmpty(conditions.getFilename())) {
            qw.like("filename", "%" + conditions.getFilename() + "%");
        }
        if (conditions.getUploadTime() != null) {
            qw.eq("upload_time", conditions.getUploadTime());
        }
        if (!StringUtils.isEmpty(conditions.getPassword())) {
            qw.eq("password", conditions.getPassword());
        }
        return u.selectCount(qw);
    }

    @Override
    public List<Image> selectUseForm(PageForm<Image> form) {
        return u.selectByPage(form);
    }
}

package com.blog.service.db.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.blog.bean.orm.table.Creator;
import com.blog.mapper.table.CreatorMapper;
import com.blog.service.db.CreatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class CreatorServiceImpl extends BaseDBServiceImpl<Creator, CreatorMapper> implements CreatorService {

    @Autowired
    private PasswordEncoder encoder;

    @Override
    public Integer insert(Creator creator) {
        creator.setPassword(encoder.encode(creator.getPassword()));
        return super.insert(creator);
    }

    @Override
    public Creator selectUseUsername(String username) {
        QueryWrapper<Creator> qw = new QueryWrapper<>();
        qw.eq("username", username);
        return u.selectOne(qw);
    }
}

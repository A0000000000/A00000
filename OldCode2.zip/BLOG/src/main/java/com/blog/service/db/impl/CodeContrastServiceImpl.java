package com.blog.service.db.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.CodeContrast;
import com.blog.mapper.table.CodeContrastMapper;
import com.blog.service.db.CodeContrastService;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 与操作CodeContrast相关的业务层接口实现类
 */
@Component
@Transactional
public class CodeContrastServiceImpl extends BaseDBServiceImpl<CodeContrast, CodeContrastMapper> implements CodeContrastService {

    @Override
    public CodeContrast selectUseName(String name) {
        QueryWrapper<CodeContrast> qw = new QueryWrapper<>();
        qw.eq("name", name);
        return u.selectOne(qw);
    }
    
    @Override
    public List<CodeContrast> selectUseForm(PageForm<CodeContrast> form) {
        return u.selectByPage(form);
    }

}

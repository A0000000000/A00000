package com.blog.service.db;

import com.blog.bean.orm.table.Creator;
import com.blog.mapper.table.CreatorMapper;

public interface CreatorService extends BaseDBService<Creator, CreatorMapper> {

    Creator selectUseUsername(String username);

}

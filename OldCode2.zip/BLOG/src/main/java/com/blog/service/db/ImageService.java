package com.blog.service.db;

import com.blog.bean.dto.PageForm;
import com.blog.bean.orm.table.Image;
import com.blog.mapper.table.ImageMapper;

import java.util.List;

public interface ImageService extends BaseDBService<Image, ImageMapper> {

    Integer count(Image conditions);

    List<Image> selectUseForm(PageForm<Image> form);

}

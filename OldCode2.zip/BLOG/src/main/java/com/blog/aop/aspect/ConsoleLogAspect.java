package com.blog.aop.aspect;

import com.alibaba.fastjson.JSONObject;
import com.blog.bean.other.JwtUser;
import com.blog.tools.utils.SecurityUtils;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.Arrays;

@Aspect
@Component
@Slf4j
public class ConsoleLogAspect {

    @Pointcut("execution(* com.blog.service..*.*(..))")
    public void ConsoleLogAspect() {}

    @Before("ConsoleLogAspect()")
    public void before(JoinPoint joinPoint) {
        log.info(String.format("execute Class: %s, Method: %s, Args: %s, UserId: %d.", joinPoint.getTarget().getClass().getName(), ((MethodSignature)joinPoint.getSignature()).getMethod().getName(), Arrays.toString(joinPoint.getArgs()), SecurityUtils.getAuthenticationUserId()));
    }

    @AfterReturning(value = "ConsoleLogAspect()", returning = "obj")
    public void afterReturning(JoinPoint joinPoint, Object obj) {
        if (obj instanceof Exception e) {
            log.info(String.format("after execute Class: %s, Method: %s, Args: %s, Exception: %s.", joinPoint.getTarget().getClass().getName(), ((MethodSignature)joinPoint.getSignature()).getMethod().getName(), Arrays.toString(joinPoint.getArgs()), e.getMessage()));
        } else {
            log.info(String.format("after execute Class: %s, Method: %s, Args: %s, Result: %s.", joinPoint.getTarget().getClass().getName(), ((MethodSignature) joinPoint.getSignature()).getMethod().getName(), Arrays.toString(joinPoint.getArgs()), JSONObject.toJSONString(obj)));
        }
    }

    @AfterThrowing(value = "ConsoleLogAspect()", throwing = "e")
    public void afterThrowing(JoinPoint joinPoint, Throwable e) {
        log.info(String.format("after execute Class: %s, Method: %s, Args: %s, Exception: %s.", joinPoint.getTarget().getClass().getName(), ((MethodSignature)joinPoint.getSignature()).getMethod().getName(), Arrays.toString(joinPoint.getArgs()), e.getMessage()));
    }

}

package com.blog.aop.interceptor;

import com.alibaba.fastjson.JSONObject;
import com.blog.bean.dto.BaseActionResult;
import com.blog.bean.orm.table.AccessSource;
import com.blog.service.db.AccessSourceService;
import com.blog.service.db.CodeContrastService;
import com.blog.tools.constant.StaticConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.nio.charset.StandardCharsets;

/**
 * 判断访问接口的来源是否可信的拦截器
 */
@Component
public class AccessSourceInterceptor implements HandlerInterceptor {

    @Autowired
    private CodeContrastService codeContrastService;
    @Autowired
    private AccessSourceService accessSourceService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String source = request.getHeader("source");
        if (StringUtils.isEmpty(source)) {
            BaseActionResult<Void> action = BaseActionResult.getErrorBean(codeContrastService.selectUseName(StaticConstant.EMPTY_SOURCE).getValue());
            String str = JSONObject.toJSONString(action);
            response.setContentType("application/json;charset=UTF-8");
            try (ServletOutputStream outputStream = response.getOutputStream()) {
                outputStream.write(str.getBytes(StandardCharsets.UTF_8));
                outputStream.flush();
            }
            return false;
        }
        AccessSource accessSource = accessSourceService.selectUseName(source);
        if (accessSource == null || accessSource.getName() == null || !accessSource.getName().equals(source)) {
            BaseActionResult<Void> action = BaseActionResult.getErrorBean(codeContrastService.selectUseName(StaticConstant.UNKNOWN_SOURCE).getValue());
            String str = JSONObject.toJSONString(action);
            response.setContentType("application/json;charset=UTF-8");
            try (ServletOutputStream outputStream = response.getOutputStream()) {
                outputStream.write(str.getBytes(StandardCharsets.UTF_8));
                outputStream.flush();
            }
            return false;
        }
        return true;
    }
}

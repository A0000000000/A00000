package com.blog.aop.interceptor;

import com.blog.bean.orm.table.AccessInfo;
import com.blog.bean.orm.table.Log;
import com.blog.service.db.AccessInfoService;
import com.blog.service.db.LogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;

/**
 * 记录访问信息的拦截器
 */
@Component
public class AccessInfoInterceptor implements HandlerInterceptor {

    @Autowired
    private AccessInfoService accessInfoService;
    @Autowired
    private LogService logService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        try {
            String ip = request.getHeader("ip");
            String url = request.getRequestURL().toString();
            if (StringUtils.isEmpty(ip)) {
                ip = request.getHeader("x-forwarded-for");
                if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                    ip = request.getHeader("Proxy-Client-IP");
                }
                if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                    ip = request.getHeader("WL-Proxy-Client-IP");
                }
                if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                    ip = request.getRemoteAddr();
                }
            }
            AccessInfo info = new AccessInfo();
            info.setIp(ip);
            info.setUrl(url);
            info.setAccessTime(new Date());
            if (info.getUrl() != null && !info.getUrl().contains("/api/admin")) {
                accessInfoService.insert(info);
            }
        } catch (Exception e) {
            Log log = new Log();
            log.setLevel("warning");
            log.setLogTime(new Date());
            log.setMessage(String.format("Interceptor Error! Cannot get access info from request. RequestURL: %s, Exception Message: %s", request.getRequestURL(), e.getMessage()));
            logService.insert(log);
        }
        return true;
    }

}

package com.blog.aop.aspect;

import com.alibaba.fastjson.JSONObject;
import com.blog.bean.dto.BaseServiceResult;
import com.blog.bean.exception.RabbitMQException;
import com.blog.bean.exception.RedisException;
import com.blog.bean.orm.table.Log;
import com.blog.bean.other.JwtUser;
import com.blog.service.db.LogService;
import com.blog.tools.utils.SecurityUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 记录日志相关的切面
 */
@Aspect
@Component
public class LogAspect {

    @Autowired
    private LogService logService;

    @Pointcut("execution(* com.blog.service.surface..*.*(..))")
    public void logAdvice() {}

    @Before("logAdvice()")
    public void before(JoinPoint joinPoint) {
        Log log = new Log();
        log.setLevel("info");
        log.setLogTime(new Date());
        log.setMessage(String.format("execute Class: %s, Method: %s, Args: %s, UserId: %d.", joinPoint.getTarget().getClass().getName(), ((MethodSignature)joinPoint.getSignature()).getMethod().getName(), Arrays.toString(joinPoint.getArgs()), SecurityUtils.getAuthenticationUserId()));
        if (!"info".equals(log.getLevel())) {
            logService.insert(log);
        }
    }

    @AfterReturning(pointcut = "logAdvice()", returning = "obj")
    public void afterReturning(JoinPoint joinPoint, Object obj) {
        Log log = new Log();
        log.setLogTime(new Date());
        Map<String, Object> m = new HashMap<>();
        m.put("execute", String.format("after execute Class: %s, Method: %s, Args: %s, UserId: %d.", joinPoint.getTarget().getClass().getName(), ((MethodSignature)joinPoint.getSignature()).getMethod().getName(), Arrays.toString(joinPoint.getArgs()),  SecurityUtils.getAuthenticationUserId()));
        if (obj instanceof BaseServiceResult<?> res) {
            Exception e = res.getE();
            if (e == null) {
                log.setLevel("info");
            } else {
                if (e instanceof RedisException rce) {
                    log.setLevel("warning");
                    m.put("message", rce.getMessage());
                    m.put("additionMessage", rce.getAdditionMessage());
                } else if (e instanceof RabbitMQException rmqe) {
                    if (RabbitMQException.TYPE_EMAIL.equals(rmqe.getType())) {
                        log.setLevel("warning");
                        m.put("type", rmqe.getType());
                        m.put("message", rmqe.getMessage());
                        m.put("additionMessage", rmqe.getAdditionMessage());
                    } else if (RabbitMQException.TYPE_IMAGE.equals(rmqe.getType())) {
                        log.setLevel("error");
                        m.put("type", rmqe.getType());
                        m.put("message", rmqe.getMessage());
                        m.put("additionMessage", rmqe.getAdditionMessage());
                    } else {
                        log.setLevel("warning");
                        m.put("type", rmqe.getType());
                        m.put("message", rmqe.getMessage());
                        m.put("additionMessage", rmqe.getAdditionMessage());
                    }
                } else {
                    log.setLevel("error");
                    m.put("message", e.getMessage());
                }
            }
        } else {
            log.setLevel("info");
        }
        log.setMessage(JSONObject.toJSONString(m));
        if (!"info".equals(log.getLevel())) {
            logService.insert(log);
        }
    }

}

# BLOG
## 博客后端重构代码
* 主要使用当前比较流行的技术进行重构
1. 以Spring Boot为核心
2. 使用Spring Security作为权限认证框架
3. 使用MyBatis Plus操作数据库
